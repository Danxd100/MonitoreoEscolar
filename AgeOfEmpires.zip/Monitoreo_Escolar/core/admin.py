from django.contrib import admin
from .models import Usuario, Alumno, Profesor, Curso, Asignatura, Anotacion, Nota, Asistencia, Semestre, AnoEscolar
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.forms import UserCreationForm, UserChangeForm

# Definir el formulario de creación de usuarios
class UsuarioCreationForm(UserCreationForm):
    class Meta:
        model = Usuario
        fields = ('rut', 'primer_nombre', 'segundo_nombre', 'appaterno', 'apmaterno', 'tipo')

# Definir el formulario de cambio de usuarios
class UsuarioChangeForm(UserChangeForm):
    class Meta:
        model = Usuario
        fields = ('rut', 'primer_nombre', 'segundo_nombre', 'appaterno', 'apmaterno', 'tipo')

# Custom User Admin
class UsuarioAdmin(UserAdmin):
    add_form = UsuarioCreationForm
    form = UsuarioChangeForm
    model = Usuario
    list_display = ['rut', 'primer_nombre', 'segundo_nombre', 'appaterno', 'apmaterno', 'tipo', 'is_staff']
    search_fields = ['rut', 'primer_nombre', 'segundo_nombre', 'appaterno', 'apmaterno']
    list_filter = ['tipo']

    # Ocultamos last_login en los formularios y agregamos el manejo de permisos y contraseña
    fieldsets = (
        (None, {'fields': ('rut', 'password')}),
        ('Información personal', {'fields': ('primer_nombre', 'segundo_nombre', 'appaterno', 'apmaterno')}),  # Incluir segundo_nombre
        ('Permisos', {'fields': ('tipo', 'is_staff', 'is_active', 'is_superuser', 'groups', 'user_permissions')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('rut', 'primer_nombre', 'segundo_nombre', 'appaterno', 'apmaterno', 'password1', 'password2', 'tipo')}  # Incluir segundo_nombre
        ),
    )
    
    ordering = ['rut']

# Registrar el modelo Usuario con el nuevo UsuarioAdmin
admin.site.register(Usuario, UsuarioAdmin)

# 1. Registrar el modelo Año Escolar
@admin.register(AnoEscolar)
class AnoEscolarAdmin(admin.ModelAdmin):
    list_display = ['nombre']
    search_fields = ['nombre']

# 2. Usar un inline para que los Semestres se puedan añadir dentro del Año Escolar
class SemestreInline(admin.TabularInline):
    model = Semestre
    extra = 1

# 3. Registrar Semestre asociado al Año Escolar
@admin.register(Semestre)
class SemestreAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'inicio', 'fin', 'ano_escolar']
    search_fields = ['nombre']
    list_filter = ['ano_escolar']

# 4. Usar un inline para que los Cursos se puedan añadir dentro del Semestre
class CursoInline(admin.TabularInline):
    model = Curso
    extra = 1

# 5. Registrar el modelo Curso
@admin.register(Curso)
class CursoAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'semestre']
    search_fields = ['nombre']
    list_filter = ['semestre']

# 6. Usar un inline para que las Asignaturas se puedan añadir dentro del Curso
class AsignaturaInline(admin.TabularInline):
    model = Asignatura
    extra = 1

# 7. Registrar el modelo Asignatura
@admin.register(Asignatura)
class AsignaturaAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'curso', 'semestre']
    search_fields = ['nombre']
    list_filter = ['curso', 'semestre']

# 9. Registrar el modelo Alumno, con relación a Usuario como apoderado y Curso
@admin.register(Alumno)
class AlumnoAdmin(admin.ModelAdmin):
    list_display = ['rut', 'primer_nombre', 'appaterno', 'curso', 'apoderado']
    search_fields = ['rut', 'primer_nombre', 'appaterno']
    list_filter = ['curso']

# 10. Registrar el modelo Profesor (los profesores añaden notas, asistencia y anotaciones)
@admin.register(Profesor)
class ProfesorAdmin(admin.ModelAdmin):
    list_display = ['usuario', 'asignaturas_display', 'es_jefe', 'curso']
    search_fields = ['usuario__primer_nombre', 'usuario__appaterno', 'asignatura__nombre']
    list_filter = ['asignatura', 'es_jefe', 'curso']

    fieldsets = (
        (None, {
            'fields': ('usuario', 'asignatura', 'es_jefe', 'curso')
        }),
    )

    def get_fields(self, request, obj=None):
        fields = super().get_fields(request, obj)
        if obj and not obj.es_jefe:
            fields.remove('curso')
        return fields


# 11. Registrar el modelo Nota
@admin.register(Nota)
class NotaAdmin(admin.ModelAdmin):
    list_display = ['alumno', 'asignatura', 'nota', 'semestre']
    search_fields = ['alumno__primer_nombre', 'alumno__appaterno', 'asignatura__nombre']
    list_filter = ['asignatura', 'semestre', 'nota']

# 12. Registrar el modelo Asistencia
@admin.register(Asistencia)
class AsistenciaAdmin(admin.ModelAdmin):
    list_display = ['alumno', 'asignatura', 'fecha', 'presente', 'semestre']
    search_fields = ['alumno__primer_nombre', 'alumno__appaterno', 'asignatura__nombre']
    list_filter = ['asignatura', 'fecha', 'presente', 'semestre']

# 13. Registrar el modelo Anotacion
@admin.register(Anotacion)
class AnotacionAdmin(admin.ModelAdmin):
    list_display = ['alumno', 'asignatura', 'tipo', 'descripcion', 'fecha']
    search_fields = ['alumno__primer_nombre', 'alumno__appaterno', 'asignatura__nombre']
    list_filter = ['tipo', 'fecha', 'asignatura']
