from django import template

register = template.Library()

@register.filter
def get_item(dictionary, key):
    """Obtiene un elemento de un diccionario usando la clave proporcionada."""
    return dictionary.get(key, '')

@register.filter
def to_float(value):
    """Convierte el valor a un número flotante."""
    try:
        return float(value)
    except (ValueError, TypeError):
        return 0.0
