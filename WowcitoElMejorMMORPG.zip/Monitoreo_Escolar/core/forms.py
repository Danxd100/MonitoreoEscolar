from django import forms
from django.forms import DateInput

from .models import Curso, AnoEscolar, Semestre, Asignatura, Alumno, Usuario, Asistencia

#from .models import Asignatura


class AnoForm(forms.ModelForm):
    class Meta:
        model = AnoEscolar
        fields = ['nombre']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el año escolar'}),
        }

class SemestreForm(forms.ModelForm):
    class Meta:
        model = Semestre
        fields = ['nombre', 'inicio', 'fin', 'ano_escolar']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el semestre'}),
            'inicio': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'fin': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'ano_escolar': forms.Select(attrs={'class': 'form-select'}),
        }

class CursoForm(forms.ModelForm):
    class Meta:
        model = Curso
        fields = ['nombre', 'semestre']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el curso'}),
            'semestre': forms.Select(attrs={'class': 'form-select'}),
        }


class AsignaturaForm(forms.ModelForm):
    class Meta:
        model = Asignatura
        fields = ['nombre', 'curso', 'semestre']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el nombre de la asignatura'}),
            'curso': forms.Select(attrs={'class': 'form-select'}),
            'semestre': forms.Select(attrs={'class': 'form-select'}),
        }



class AlumnoForm(forms.ModelForm):
    class Meta:
        model = Alumno
        fields = ['rut', 'primer_nombre', 'segundo_nombre', 'appaterno', 'apmaterno', 'curso']
        widgets = {
            'rut': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el RUT'}),
            'primer_nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el primer nombre'}),
            'segundo_nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el segundo nombre'}),
            'appaterno': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el apellido paterno'}),
            'apmaterno': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el apellido materno'}),
            'curso': forms.Select(attrs={'class': 'form-select'}),
        }
        exclude = ['apoderado']


class ProfesorForm(forms.ModelForm):
    password1 = forms.CharField(
        label='Contraseña',
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese la contraseña'})
    )
    password2 = forms.CharField(
        label='Confirmar Contraseña',
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Confirme la contraseña'})
    )
    asignatura = forms.ModelChoiceField(
        queryset=Asignatura.objects.all(),
        label="Asignatura",
        required=True,
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    es_jefe = forms.BooleanField(
        label="Es Profesor Jefe",
        required=False,
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input', 'id': 'id_es_jefe'})
    )
    curso = forms.ModelChoiceField(
        queryset=Curso.objects.all(),
        label="Curso",
        required=False,
        widget=forms.Select(attrs={'class': 'form-select', 'id': 'id_curso'})
    )

    class Meta:
        model = Usuario
        fields = ['rut', 'primer_nombre', 'segundo_nombre', 'appaterno', 'apmaterno']
        widgets = {
            'rut': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el RUT'}),
            'primer_nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el primer nombre'}),
            'segundo_nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el segundo nombre'}),
            'appaterno': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el apellido paterno'}),
            'apmaterno': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el apellido materno'}),
        }

    def clean_password2(self):
        password1 = self.cleaned_data.get("password1")
        password2 = self.cleaned_data.get("password2")
        if password1 and password2 and password1 != password2:
            raise forms.ValidationError("Las contraseñas no coinciden.")
        return password2

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password1"])
        user.tipo = 'profesor'
        if commit:
            user.save()
        return user




class ApoderadoForm(forms.ModelForm):
    password1 = forms.CharField(
        label='Contraseña', 
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese la contraseña'})
    )
    password2 = forms.CharField(
        label='Confirmar Contraseña', 
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Confirme la contraseña'})
    )

    class Meta:
        model = Usuario
        fields = ['rut', 'primer_nombre', 'segundo_nombre', 'appaterno', 'apmaterno']
        widgets = {
            'rut': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el RUT'}),
            'primer_nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el primer nombre'}),
            'segundo_nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el segundo nombre'}),
            'appaterno': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el apellido paterno'}),
            'apmaterno': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el apellido materno'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['tipo'] = forms.CharField(
            initial='apoderado', 
            widget=forms.HiddenInput()
        )  # Campo oculto con valor predeterminado "apoderado"

    def clean_password2(self):
        password1 = self.cleaned_data.get("password1")
        password2 = self.cleaned_data.get("password2")
        if password1 and password2 and password1 != password2:
            raise forms.ValidationError("Las contraseñas no coinciden.")
        return password2

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password1"])
        user.tipo = 'apoderado'  # Asignar tipo directamente
        if commit:
            user.save()
        return user



class AsistenciaForm(forms.ModelForm):
    class Meta:
        model = Asistencia
        fields = ['presente']  # Solo necesitamos la columna 'presente' para el formulario
