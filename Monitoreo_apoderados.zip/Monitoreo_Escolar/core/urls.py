from django.urls import path
from django.contrib.auth import views as auth_views

from .views import *
from . import views

urlpatterns = [
    path('', login_view, name='login'),  # Usa la nueva vista de login personalizada
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('registro', registro_view, name='registro'),
    path('registroadmin', registroadmin_view, name='registroadmin'),

    path('crear_curso/', views.crear_curso, name='crear_curso'),
    path('crear_asignatura/', crear_asignatura, name='crear_asignatura'),
    path('crear_alumno/', views.crear_alumno, name='crear_alumno'),
    path('crear_alumno/<int:apoderado_id>/', crear_alumno, name='crear_alumno'),  # Para agregar alumno a un apoderado específico
    path('crear_profesor/', crear_profesor, name='crear_profesor'),

    path('eliminar/<str:model_name>/<int:id_objeto>/', views.eliminar_objeto, name='eliminar_objeto'),
    path('modificar/<str:model_name>/<int:id_objeto>/', views.modificar_objeto, name='modificar_objeto'),

    path('notas_alumno', ver_notas_view, name='ver_notas'),
    path('anotaciones_alumno', ver_anotaciones_view, name='ver_anotaciones'),
    path('asistencias_alumno', ver_asistencias_view, name='ver_asistencias'),
]
