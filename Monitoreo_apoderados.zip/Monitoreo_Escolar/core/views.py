from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.http import HttpResponseRedirect
from django.contrib.contenttypes.models import ContentType
from django.contrib.auth import authenticate, login

from .forms import CursoForm, SemestreForm, AnoForm, AsignaturaForm, AlumnoForm, ProfesorForm, ApoderadoForm
from .models import Curso, Semestre, AnoEscolar, Asignatura, Alumno, Usuario, Profesor, Asistencia

from django.shortcuts import render, get_object_or_404, redirect

from django.contrib.auth import authenticate, login as auth_login


from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login as auth_login
from django.http import HttpResponseRedirect


def login_view(request):
    if request.method == 'POST':
        rut = request.POST.get('rut')  # Usamos RUT
        password = request.POST.get('password')
        
        # Autenticamos con RUT como el nombre de usuario
        user = authenticate(request, username=rut, password=password)
        
        if user is not None:
            auth_login(request, user)
            
            # Verificar si el usuario es superuser o staff y redirigir en consecuencia
            if user.is_superuser or user.is_staff:
                return redirect('registroadmin')  # Redirige a la página de administrador
            elif user.tipo == 'profesor':
                return redirect('registro')  # Redirige a la página de profesor
            elif user.tipo == 'apoderado':
                return redirect('registro')  # Redirige a la página de apoderado
            else:
                return redirect('login.html')  # Redirige a la página principal para usuarios normales
        else:
            return render(request, 'login.html', {'error': 'RUT o contraseña incorrectos'})
    
    return render(request, 'login.html')


@login_required
def registro_view(request):

    return render(request, 'registro.html')

@login_required
@user_passes_test(lambda u: u.is_superuser or u.is_staff)
def registroadmin_view(request):

    return render(request, 'registroadmin.html')
"""
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
"""
# Vista para crear Año Escolar, Semestre y Curso
@login_required
@user_passes_test(lambda u: u.is_superuser or u.is_staff)
def crear_curso(request):
    # Inicializar los formularios
    ano_form = AnoForm(request.POST or None)
    semestre_form = SemestreForm(request.POST or None)
    curso_form = CursoForm(request.POST or None)

    # Manejar la lógica del formulario basado en el botón que se presionó
    if request.method == 'POST':
        if 'guardar_ano' in request.POST and ano_form.is_valid():
            ano_form.save()
            return redirect('crear_curso')  # Redirigir después de guardar

        elif 'guardar_semestre' in request.POST and semestre_form.is_valid():
            semestre_form.save()
            return redirect('crear_curso')  # Redirigir después de guardar

        elif 'guardar_curso' in request.POST and curso_form.is_valid():
            curso_form.save()
            return redirect('crear_curso')  # Redirigir después de guardar

    # Pasar formularios al contexto
    return render(request, 'crear_curso.html', {
        'ano_form': ano_form,
        'semestre_form': semestre_form,
        'curso_form': curso_form,
        'anoescolares': AnoEscolar.objects.all(),  # Obtener años escolares para mostrar en la plantilla
        'semestres': Semestre.objects.all(),  # Obtener semestres si es necesario
        'cursos': Curso.objects.all()  # Obtener cursos si es necesario
    })

# Vista para crear Asignatura
@login_required
@user_passes_test(lambda u: u.is_superuser or u.is_staff)
def crear_asignatura(request):
    if request.method == 'POST':
        asignatura_form = AsignaturaForm(request.POST)
        if asignatura_form.is_valid():
            asignatura_form.save()
            return redirect('crear_asignatura')
    else:
        asignatura_form = AsignaturaForm()

    # Obtener listas de cursos y semestres si es necesario
    cursos = Curso.objects.all()
    semestres = Semestre.objects.all()
    asignaturas = Asignatura.objects.all()  # Opcional, si quieres mostrar las asignaturas existentes

    return render(request, 'crear_asignatura.html', {
        'asignatura_form': asignatura_form,
        'cursos': cursos,
        'semestres': semestres,
        'asignaturas': asignaturas,
    })

# Vista para crear Alumno
@login_required
@user_passes_test(lambda u: u.is_superuser or u.is_staff)
def crear_alumno(request):
    # Inicializamos el formulario de apoderado
    apoderado_form = ApoderadoForm()

    if request.method == 'POST':
        if 'guardar_alumno' in request.POST:
            alumno_form = AlumnoForm(request.POST)
            apoderado_id = request.POST.get('apoderado_id')  # Obtenemos el ID del apoderado automáticamente

            if alumno_form.is_valid() and apoderado_id:
                # Creamos el objeto alumno pero no lo guardamos aún
                alumno = alumno_form.save(commit=False)
                # Asignamos el apoderado al alumno utilizando el ID
                alumno.apoderado = Usuario.objects.get(id=apoderado_id)
                alumno.save()
                return redirect('crear_alumno')  # Redirigir para evitar reenvío del formulario

        elif 'guardar_apoderado' in request.POST:
            apoderado_form = ApoderadoForm(request.POST)
            if apoderado_form.is_valid():
                apoderado_form.save()
                return redirect('crear_alumno')

    else:
        # Inicializamos los formularios si es un GET
        alumno_form = AlumnoForm()

    return render(request, 'crear_alumno.html', {
        'alumno_form': alumno_form,
        'apoderado_form': apoderado_form,
        'apoderados': Usuario.objects.filter(tipo='apoderado'),  # Solo mostrar apoderados
        'alumnos': Alumno.objects.all(),  # Mostrar alumnos existentes
    })


@login_required
@user_passes_test(lambda u: u.is_superuser or u.is_staff)
def crear_profesor(request):
    if request.method == 'POST':
        profesor_form = ProfesorForm(request.POST)
        if profesor_form.is_valid():
            usuario_profesor = profesor_form.save()  # Guardamos el profesor como usuario
            asignatura = profesor_form.cleaned_data.get('asignatura')  # Obtenemos la asignatura seleccionada
            es_jefe = profesor_form.cleaned_data.get('es_jefe')  # Obtenemos si es profesor jefe
            # Creamos la relación entre el usuario y la asignatura en la tabla Profesor, y si es jefe
            Profesor.objects.create(usuario=usuario_profesor, asignatura=asignatura, es_jefe=es_jefe)
            return redirect('crear_profesor')  # Redirige a la misma página después de crear el profesor
    else:
        profesor_form = ProfesorForm()

    profesores = Usuario.objects.filter(tipo='profesor')  # Solo trae los usuarios que son profesores

    return render(request, 'crear_profesor.html', {'profesor_form': profesor_form, 'profesores': profesores})


"""
------------------------------------------------------------------------------------------------------------------------------------------------------
"""

# Vista para modificar
@login_required
def modificar_objeto(request, model_name, id_objeto):
    model_mapping = {
        'anoescolar': (AnoEscolar, AnoForm),
        'semestre': (Semestre, SemestreForm),
        'curso': (Curso, CursoForm),
        'asignatura': (Asignatura, AsignaturaForm),
        'alumno': (Alumno, AlumnoForm),
        'profesor': (Usuario, ProfesorForm),
        'apoderado':(Usuario, ApoderadoForm), 
    }

    model_class, form_class = model_mapping.get(model_name)

    if model_class and form_class:
        objeto = get_object_or_404(model_class, id=id_objeto)

        if request.method == 'POST':
            form = form_class(request.POST, instance=objeto)
            if form.is_valid():
                form.save()
                if model_name == 'asignatura':
                    return redirect('crear_asignatura')  # Redirige a la página de asignaturas
                elif model_name == 'curso':
                    return redirect('crear_curso')  # Redirige a la página de cursos
                elif model_name == 'anoescolar':
                    return redirect('crear_curso')  # Redirige a la página de año escolar
                elif model_name == 'semestre':
                    return redirect('crear_curso')  # Redirige a la página de semestre
                elif model_name == 'alumno':
                    return redirect('crear_alumno')  # Redirige a la página de alumnos
                elif model_name == 'profesor':
                    return redirect('crear_profesor')  # Redirige a la página de profesores
                elif model_name == 'apoderado':
                    return redirect('crear_alumno')  # Redirige a la página de apoderados
                return redirect('registroadmin')
        else:
            form = form_class(instance=objeto)
        return render(request, 'modificar_objeto.html', {'form': form, 'model_name': model_name})
    return redirect('registroadmin')

# Vista para eliminar
@login_required
def eliminar_objeto(request, model_name, id_objeto):
    model_mapping = {
        'anoescolar': AnoEscolar,
        'semestre': Semestre,
        'curso': Curso,
        'asignatura': Asignatura,
        'alumno': Alumno, 
        'profesor': Usuario,
        'apoderado':Usuario,  
    }
    
    model_class = model_mapping.get(model_name)

    if model_class:
        objeto = get_object_or_404(model_class, id=id_objeto)
        objeto.delete()

        # Redirige según el tipo de objeto eliminado
        if model_name == 'asignatura':
            return redirect('crear_asignatura')  # Redirige a la página de asignaturas
        elif model_name == 'curso':
            return redirect('crear_curso')  # Redirige a la página de cursos
        elif model_name == 'anoescolar':
            return redirect('crear_curso')  # Redirige a la página de año escolar
        elif model_name == 'semestre':
            return redirect('crear_curso')  # Redirige a la página de semestre
        elif model_name == 'alumno':
            return redirect('crear_alumno')  # Redirige a la página de alumnos
        elif model_name == 'profesor':
            return redirect('crear_profesor')  # Redirige a la página de profesores
        elif model_name == 'apoderado':
            return redirect('crear_alumno')  # Redirige a la página de apoderados
    return redirect('registroadmin')  # Redirección por defecto



@login_required
def ver_notas_view(request):

    return render(request, 'ver_notas.html')


@login_required
def ver_asistencias_view(request):
    # Verifica que el usuario sea un apoderado
    if request.user.tipo == 'apoderado':
        # Encuentra a los alumnos relacionados con el apoderado
        alumnos = Alumno.objects.filter(apoderado=request.user)
        
        # Busca las asistencias de los alumnos
        asistencias_por_alumno = {}
        for alumno in alumnos:
            asistencias = Asistencia.objects.filter(alumno=alumno)
            asistencias_por_alumno[alumno] = asistencias

        return render(request, 'ver_asistencias.html', {
            'asistencias_por_alumno': asistencias_por_alumno,
        })
    else:
        return redirect('login')  # Si no es apoderado, redirige a login

@login_required
def ver_anotaciones_view(request):

    return render(request, 'ver_anotaciones.html')


