from django.shortcuts import render, get_object_or_404, redirect
from .models import Curso
from .forms import CursoForm


def index(request):

    return render(request, 'index.html')



def registro(request):

    return render(request, 'registro.html')



def registroadmin(request):

    return render(request, 'registroadmin.html')

# Listar cursos
def listar_cursos(request):
    cursos = Curso.objects.all()
    return render(request, 'listar_cursos.html', {'cursos': cursos})

# Crear curso
def crear_curso(request):
    if request.method == 'POST':
        form = CursoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar_cursos')
    else:
        form = CursoForm()
    return render(request, 'curso_form.html', {'form': form})

# Editar curso
def editar_curso(request, id_curso):
    curso = get_object_or_404(Curso, id_curso=id_curso)
    if request.method == 'POST':
        form = CursoForm(request.POST, instance=curso)
        if form.is_valid():
            form.save()
            return redirect('listar_cursos')
    else:
        form = CursoForm(instance=curso)
    return render(request, 'curso_form.html', {'form': form})

# Confirmar eliminación de curso
def confirmar_eliminar(request, id_curso):
    curso = get_object_or_404(Curso, id_curso=id_curso)
    if request.method == 'POST':
        curso.delete()
        return redirect('listar_cursos')
    return render(request, 'confirmar_eliminar.html', {'curso': curso})