from django.urls import path
from . import views

from .views import *

urlpatterns = [
    path('', index,name="index"),
    path('registro.html', registro, name='registro'),
    path('registroadmin.html/', registroadmin, name='registroadmin'),
    
    path('cursos/', views.listar_cursos, name='listar_cursos'),  # Ruta para listar cursos
    path('cursos/create/', views.crear_curso, name='crear_curso'),  # Ruta para crear curso
    path('cursos/<str:id_curso>/edit/', views.editar_curso, name='curso_form'),  # Ruta para editar curso
    path('cursos/<str:id_curso>/delete/', views.confirmar_eliminar, name='confirmar_eliminar'),  # Ruta para eliminar curso
]
