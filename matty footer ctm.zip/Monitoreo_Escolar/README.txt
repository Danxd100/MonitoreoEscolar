instalar

py -m pip install xhtml2pdf
si no sirve
pip install xhtml2pdf

