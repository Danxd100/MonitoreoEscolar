from django import forms
from django.forms import DateInput
from django.core.exceptions import ValidationError
from datetime import date
from .models import Curso, AnoEscolar, Semestre, Asignatura, Alumno, Usuario, Asistencia
import re
from django.contrib.auth.hashers import make_password
#from .models import Asignatura

class AnoForm(forms.ModelForm):
    class Meta:
        model = AnoEscolar
        fields = ['nombre']
        widgets = {
            'nombre': forms.NumberInput(attrs={
                'class': 'form-control', 
                'placeholder': 'Ingrese el año escolar',
                'min': '1900',  # Rango mínimo ajustado
                'max': '2100'   # Rango máximo ajustado
            }),
        }

    def clean_nombre(self):
        nombre = self.cleaned_data.get('nombre')

        # Convertir a entero si es posible
        try:
            nombre = int(nombre)
        except ValueError:
            raise ValidationError('El nombre del año escolar debe ser un número válido.')

        # Verificar si el nombre está dentro del rango permitido
        if nombre < 1900 or nombre > 2100:
            raise ValidationError('El año escolar debe estar entre 1900 y 2100.')

        # Validación para evitar duplicados
        if AnoEscolar.objects.filter(nombre=nombre).exists():
            raise ValidationError('Este año escolar ya está registrado. Por favor ingrese un año diferente.')

        return nombre

class SemestreForm(forms.ModelForm):
    class Meta:
        model = Semestre
        fields = ['nombre', 'inicio', 'fin', 'ano_escolar']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el semestre'}),
            'inicio': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'fin': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'ano_escolar': forms.Select(attrs={'class': 'form-select'}),
        }

    def clean(self):
        cleaned_data = super().clean()
        inicio = cleaned_data.get("inicio")
        fin = cleaned_data.get("fin")
        ano_escolar = cleaned_data.get("ano_escolar")

        # Verificación de que la fecha de inicio sea anterior a la fecha de fin
        if inicio and fin and inicio > fin:
            self.add_error('fin', 'La fecha de inicio debe ser anterior a la fecha de fin.')

        # Verificación de solapamiento de fechas en el mismo año escolar
        if inicio and fin and ano_escolar:
            overlapping_semestres = Semestre.objects.filter(
                ano_escolar=ano_escolar,
                inicio__lte=fin,
                fin__gte=inicio
            ).exclude(pk=self.instance.pk)  # Excluir el semestre actual en caso de edición

            if overlapping_semestres.exists():
                self.add_error('ano_escolar', 'No puedes agregar 2 semestres iguales.')

        return cleaned_data

class CursoForm(forms.ModelForm):
    class Meta:
        model = Curso
        fields = ['nombre', 'semestre']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el curso'}),
            'semestre': forms.Select(attrs={'class': 'form-select'}),
        }

    def clean(self):
        cleaned_data = super().clean()
        nombre = cleaned_data.get("nombre")
        semestre = cleaned_data.get("semestre")

        # Verificación de duplicados en nombre y semestre
        if nombre and semestre:
            duplicate_curso = Curso.objects.filter(
                nombre=nombre,
                semestre=semestre
            ).exclude(pk=self.instance.pk)  # Excluir el curso actual en caso de edición

            if duplicate_curso.exists():
                self.add_error('semestre', 'Ya existe un curso con este nombre en el semestre seleccionado.')

        return cleaned_data

class AsignaturaForm(forms.ModelForm):
    class Meta:
        model = Asignatura
        fields = ['nombre', 'curso', 'semestre']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el nombre de la asignatura'}),
            'curso': forms.Select(attrs={'class': 'form-select'}),
            'semestre': forms.Select(attrs={'class': 'form-select'}),
        }

    def clean(self):
        cleaned_data = super().clean()
        nombre = cleaned_data.get("nombre")
        curso = cleaned_data.get("curso")
        semestre = cleaned_data.get("semestre")

        # Validación para evitar asignaturas duplicadas con el mismo nombre, curso y semestre
        if nombre and curso and semestre:
            asignatura_duplicada = Asignatura.objects.filter(
                nombre=nombre,
                curso=curso,
                semestre=semestre
            ).exclude(pk=self.instance.pk)  # Excluir en caso de edición

            if asignatura_duplicada.exists():
                self.add_error('curso', 'Ya existe una asignatura con este nombre en el curso y semestre seleccionados.')
                self.add_error('semestre', 'Ya existe una asignatura con este nombre en el curso y semestre seleccionados.')

        return cleaned_data

class AlumnoForm(forms.ModelForm):
    class Meta:
        model = Alumno
        fields = ['rut', 'primer_nombre', 'segundo_nombre', 'appaterno', 'apmaterno', 'curso']
        labels = {
            'primer_nombre': 'Nombre',
            'segundo_nombre': 'Segundo nombre',
            'appaterno': 'Apellido paterno', 
            'apmaterno': 'Apellido materno',
            'rut': 'RUT'
        }
        widgets = {
            'rut': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ingrese el RUT',
                'maxlength': '12',
                'oninput': 'formatearRut(this)'
            }),
            'primer_nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el primer nombre'}),
            'segundo_nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el segundo nombre'}),
            'appaterno': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el apellido paterno'}),
            'apmaterno': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el apellido materno'}),
            'curso': forms.Select(attrs={'class': 'form-select'}),
        }

    def clean_rut(self):
        rut = self.cleaned_data['rut']
        # Eliminar caracteres no válidos como puntos y guiones
        rut = re.sub(r'[^0-9Kk]', '', rut)
        cuerpo = rut[:-1]
        dv = rut[-1].upper()
    
        # Validar el cuerpo del RUT
        if not cuerpo.isdigit():
            raise ValidationError("El cuerpo del RUT debe contener solo números.")
    
        # Calcular el dígito verificador esperado
        expected_dv = self.calcular_dv(cuerpo)
        if dv != expected_dv:
            raise ValidationError(f"El RUT no es válido. El dígito verificador esperado es '{expected_dv}'.")
    
        # Formatear el RUT para guardarlo limpio
        cuerpo_formateado = f"{int(cuerpo):,}".replace(",", ".")
        rut_formateado = f"{cuerpo_formateado}-{dv}"
    
        self.cleaned_data['rut'] = rut_formateado
        return rut_formateado
    
    def calcular_dv(self, cuerpo):
        """
        Calcula el dígito verificador (DV) de un RUT chileno.
        """
        suma = 0
        multiplicador = 2
    
        for digito in reversed(cuerpo):
            suma += int(digito) * multiplicador
            multiplicador += 1
            if multiplicador > 7:
                multiplicador = 2
    
        resto = 11 - (suma % 11)
        if resto == 11:
            return "0"
        elif resto == 10:
            return "K"
        else:
            return str(resto)
    

    def formatear_rut(self, rut):
        cuerpo = rut[:-1]
        dv = rut[-1]
        cuerpo_formateado = f"{int(cuerpo):,}".replace(",", ".")
        return f"{cuerpo_formateado}-{dv}"

class ProfesorForm(forms.ModelForm):
    asignatura = forms.ModelMultipleChoiceField(
        queryset=Asignatura.objects.select_related('curso', 'semestre').all(),
        label="Asignaturas",
        required=True,
        widget=forms.CheckboxSelectMultiple
    )
    es_jefe = forms.BooleanField(
        label="Es Profesor Jefe",
        required=False,
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input', 'id': 'id_es_jefe'})
    )
    curso = forms.ModelChoiceField(
        queryset=Curso.objects.all(),
        label="",
        required=False,
        widget=forms.Select(attrs={'class': 'form-select', 'id': 'id_curso'}),
        empty_label="Seleccione curso asignado"
    )

    class Meta:
        model = Usuario
        fields = ['rut', 'primer_nombre', 'segundo_nombre', 'appaterno', 'apmaterno']
        labels = {
            'primer_nombre': 'Nombre',
            'segundo_nombre': 'Segundo nombre',
            'appaterno': 'Apellido paterno', 
            'apmaterno': 'Apellido materno',
            'rut': 'RUT'
        }
        widgets = {
            'rut': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ingrese RUT',
                'maxlength': '12',
                'oninput': 'formatearRut(this)'
            }),
            'primer_nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el primer nombre'}),
            'segundo_nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el segundo nombre'}),
            'appaterno': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el apellido paterno'}),
            'apmaterno': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el apellido materno'}),
        }

    def __init__(self, *args, **kwargs):
        super(ProfesorForm, self).__init__(*args, **kwargs)
        
        # Personalizar cada opción de asignatura para incluir el curso
        self.fields['asignatura'].choices = [
            (asignatura.id, f"{asignatura.nombre} ({asignatura.curso.nombre})") 
            for asignatura in self.fields['asignatura'].queryset
        ]
        
        # Ajustar clases para campos de entrada
        for field in self.fields:
            self.fields[field].required = False  # Desactivar 'required' en el HTML
            if field not in ['asignatura', 'es_jefe']:  
                css_class = 'form-control is-invalid' if self[field].errors else 'form-control'
                self.fields[field].widget.attrs.update({'class': css_class})

    def clean_rut(self):
        rut = self.cleaned_data['rut']
        # Eliminar caracteres no válidos como puntos y guiones
        rut = re.sub(r'[^0-9Kk]', '', rut)
        cuerpo = rut[:-1]
        dv = rut[-1].upper()

        # Validar el cuerpo del RUT
        if not cuerpo.isdigit():
            raise ValidationError("El cuerpo del RUT debe contener solo números.")

        # Calcular el dígito verificador esperado
        expected_dv = self.calcular_dv(cuerpo)
        if dv != expected_dv:
            raise ValidationError(f"El RUT no es válido. El dígito verificador esperado es '{expected_dv}'.")

        # Formatear el RUT para guardarlo limpio
        cuerpo_formateado = f"{int(cuerpo):,}".replace(",", ".")
        rut_formateado = f"{cuerpo_formateado}-{dv}"

        self.cleaned_data['rut'] = rut_formateado
        return rut_formateado

    def calcular_dv(self, cuerpo):
        """
        Calcula el dígito verificador (DV) de un RUT chileno.
        """
        suma = 0
        multiplicador = 2

        for digito in reversed(cuerpo):
            suma += int(digito) * multiplicador
            multiplicador += 1
            if multiplicador > 7:
                multiplicador = 2

        resto = 11 - (suma % 11)
        if resto == 11:
            return "0"
        elif resto == 10:
            return "K"
        else:
            return str(resto)


    def formatear_rut(self, rut):
        cuerpo = rut[:-1]
        dv = rut[-1]
        cuerpo_formateado = f"{int(cuerpo):,}".replace(",", ".")
        return f"{cuerpo_formateado}-{dv}"

    def clean(self):
        cleaned_data = super().clean()
        primer_nombre = cleaned_data.get('primer_nombre')
        appaterno = cleaned_data.get('appaterno')
        apmaterno = cleaned_data.get('apmaterno')
        asignatura = cleaned_data.get('asignatura')
        es_jefe = cleaned_data.get('es_jefe')
        curso = cleaned_data.get('curso')

        if not primer_nombre:
            self.add_error('primer_nombre', 'El primer nombre es obligatorio.')
        if not appaterno:
            self.add_error('appaterno', 'El apellido paterno es obligatorio.')
        if not apmaterno:
            self.add_error('apmaterno', 'El apellido materno es obligatorio.')
        if not asignatura:
            self.add_error('asignatura', 'Debe seleccionar al menos una asignatura.')

        # Validación para que el campo `curso` sea obligatorio si `es_jefe` está seleccionado
        if es_jefe and not curso:
            self.add_error('curso', 'Debe seleccionar un curso si el profesor es jefe.')

        return cleaned_data

    def save(self, commit=True):
        usuario = super().save(commit=False)

        # Generar contraseña automática
        primer_nombre = self.cleaned_data['primer_nombre']
        rut = self.cleaned_data['rut']
        appaterno = self.cleaned_data['appaterno']
        password = (primer_nombre[:2].lower() + rut[:2] + appaterno[:3].upper())

        if hasattr(usuario, 'set_password') and callable(usuario.set_password):
            usuario.set_password(password)
        else:
            usuario.clave = password

        usuario.tipo = 'profesor'
        if commit:
            usuario.save()
            self.save_m2m()
        return usuario


class ApoderadoForm(forms.ModelForm):
    class Meta:
        model = Usuario
        fields = ['rut', 'primer_nombre', 'segundo_nombre', 'appaterno', 'apmaterno']
        labels = {
            'primer_nombre': 'Nombre',
            'segundo_nombre': 'Segundo nombre',
            'appaterno': 'Apellido paterno', 
            'apmaterno': 'Apellido materno',
            'rut': 'RUT'
        }
        widgets = {
            'rut': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ingrese RUT',
                'maxlength': '12',
                'oninput': 'formatearRut(this)'
            }),
            'primer_nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el primer nombre'}),
            'segundo_nombre': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el segundo nombre'}),
            'appaterno': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el apellido paterno'}),
            'apmaterno': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ingrese el apellido materno'}),
        }

    def __init__(self, *args, **kwargs):
        super(ApoderadoForm, self).__init__(*args, **kwargs)
        for field in self.fields:
            # Desactiva `required` en el HTML para evitar la validación del navegador
            self.fields[field].required = False  
            # Añade la clase 'is-invalid' si hay errores en el campo
            if self[field].errors:
                self.fields[field].widget.attrs.update({'class': 'form-control is-invalid'})
            else:
                self.fields[field].widget.attrs.update({'class': 'form-control'})

    def clean_rut(self):
        rut = self.cleaned_data['rut']
        # Eliminar caracteres no válidos como puntos y guiones
        rut = re.sub(r'[^0-9Kk]', '', rut)
        cuerpo = rut[:-1]
        dv = rut[-1].upper()

        # Validar el cuerpo del RUT
        if not cuerpo.isdigit():
            raise ValidationError("El cuerpo del RUT debe contener solo números.")

        # Calcular el dígito verificador esperado
        expected_dv = self.calcular_dv(cuerpo)
        if dv != expected_dv:
            raise ValidationError(f"El RUT no es válido. El dígito verificador esperado es '{expected_dv}'.")

        # Formatear el RUT para guardarlo limpio
        cuerpo_formateado = f"{int(cuerpo):,}".replace(",", ".")
        rut_formateado = f"{cuerpo_formateado}-{dv}"

        self.cleaned_data['rut'] = rut_formateado
        return rut_formateado

    def calcular_dv(self, cuerpo):
        """
        Calcula el dígito verificador (DV) de un RUT chileno.
        """
        suma = 0
        multiplicador = 2

        for digito in reversed(cuerpo):
            suma += int(digito) * multiplicador
            multiplicador += 1
            if multiplicador > 7:
                multiplicador = 2

        resto = 11 - (suma % 11)
        if resto == 11:
            return "0"
        elif resto == 10:
            return "K"
        else:
            return str(resto)


    def formatear_rut(self, rut):
        cuerpo = rut[:-1]
        dv = rut[-1]
        cuerpo_formateado = f"{int(cuerpo):,}".replace(",", ".")
        return f"{cuerpo_formateado}-{dv}"

    def clean(self):
        cleaned_data = super().clean()
        primer_nombre = cleaned_data.get('primer_nombre')
        appaterno = cleaned_data.get('appaterno')
        apmaterno = cleaned_data.get('apmaterno')

        # Validación de obligatoriedad
        if not primer_nombre:
            self.add_error('primer_nombre', 'El primer nombre es obligatorio.')
        if not appaterno:
            self.add_error('appaterno', 'El apellido paterno es obligatorio.')
        if not apmaterno:
            self.add_error('apmaterno', 'El apellido materno es obligatorio.')

        return cleaned_data

    def save(self, commit=True):
        usuario = super().save(commit=False)

        # Generar la contraseña de forma automática en el backend
        primer_nombre = self.cleaned_data['primer_nombre']
        rut = self.cleaned_data['rut']
        appaterno = self.cleaned_data['appaterno']
        password = (primer_nombre[:2].lower() + rut[:2] + appaterno[:3].upper())
        
        # Guardar la contraseña encriptada en el campo de contraseña
        usuario.set_password(password)

        usuario.tipo = 'apoderado'
        if commit:
            usuario.save()
        return usuario


class AsistenciaForm(forms.ModelForm):
    class Meta:
        model = Asistencia
        fields = ['presente']  # Solo necesitamos la columna 'presente' para el formulario
