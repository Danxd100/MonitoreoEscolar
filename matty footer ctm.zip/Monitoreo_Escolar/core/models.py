from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models
from django.core.exceptions import ValidationError

class UsuarioManager(BaseUserManager):
    def create_user(self, rut, password=None, **extra_fields):
        if not rut:
            raise ValueError('El RUT es obligatorio')
        user = self.model(rut=rut, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, rut, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        return self.create_user(rut, password, **extra_fields)

class Usuario(AbstractBaseUser, PermissionsMixin):  # Ahora hereda también de PermissionsMixin
    ADMIN = 'admin'
    PROFESOR = 'profesor'
    APODERADO = 'apoderado'
    TIPO_USUARIO_CHOICES = [
        (ADMIN, 'Admin'),
        (PROFESOR, 'Profesor'),
        (APODERADO, 'Apoderado'),
    ]

    rut = models.CharField(max_length=12, unique=True)
    primer_nombre = models.CharField(max_length=30)
    segundo_nombre = models.CharField(max_length=30, blank=True, null=True)
    appaterno = models.CharField(max_length=30)
    apmaterno = models.CharField(max_length=30)
    tipo = models.CharField(max_length=10, choices=TIPO_USUARIO_CHOICES)
    
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)

    objects = UsuarioManager()

    USERNAME_FIELD = 'rut'
    REQUIRED_FIELDS = []

    def save(self, *args, **kwargs):
        if self.tipo == self.ADMIN:
            self.is_staff = True
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.rut} - {self.primer_nombre} {self.appaterno}"

    # Método para que el admin funcione correctamente
    def has_perm(self, perm, obj=None):
        return True

    # Método para verificar si el usuario tiene permisos para una app
    def has_module_perms(self, app_label):
        return True



# Modelo de Curso
class Curso(models.Model):
    nombre = models.CharField(max_length=50)
    semestre = models.ForeignKey('Semestre', on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return self.nombre

# Modelo de Asignatura
class Asignatura(models.Model):
    nombre = models.CharField(max_length=50)
    curso = models.ForeignKey(Curso, on_delete=models.CASCADE)
    semestre = models.ForeignKey('Semestre', on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return self.nombre

# Modelo de Alumno
class Alumno(models.Model):
    rut = models.CharField(max_length=12, unique=True)
    primer_nombre = models.CharField(max_length=30)
    segundo_nombre = models.CharField(max_length=30, blank=True, null=True)
    appaterno = models.CharField(max_length=30)
    apmaterno = models.CharField(max_length=30)
    curso = models.ForeignKey(Curso, on_delete=models.SET_NULL, null=True)
    apoderado = models.ForeignKey(Usuario, on_delete=models.SET_NULL, null=True, limit_choices_to={'tipo': 'apoderado'})

    def __str__(self):
        return f"{self.primer_nombre} {self.appaterno}"

# Modelo de Profesor
class Profesor(models.Model):
    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE, limit_choices_to={'tipo': 'profesor'})
    asignatura = models.ManyToManyField(Asignatura)
    es_jefe = models.BooleanField(default=False)
    curso = models.ForeignKey(Curso, on_delete=models.SET_NULL, null=True, blank=True)

    def clean(self):
        if self.es_jefe and not self.curso:
            raise ValidationError("Un profesor que es jefe debe tener un curso asignado.")
        if not self.es_jefe and self.curso:
            raise ValidationError("Solo los profesores jefes pueden tener un curso asignado.")

    def asignaturas_display(self):
        return ", ".join(asignatura.nombre for asignatura in self.asignatura.all())
    asignaturas_display.short_description = 'Asignaturas'

    def __str__(self):
        jefe_info = " (Jefe de curso)" if self.es_jefe else ""
        return f"Profesor: {self.usuario.primer_nombre} {self.usuario.appaterno}{jefe_info}"



# Modelo de Anotaciones
class Anotacion(models.Model):
    alumno = models.ForeignKey(Alumno, on_delete=models.CASCADE)
    asignatura = models.ForeignKey(Asignatura, on_delete=models.CASCADE)  # Nueva relación con Asignatura
    TIPO_ANOTACION_CHOICES = [
        ('positiva', 'Positiva'),
        ('negativa', 'Negativa'),
    ]
    tipo = models.CharField(max_length=10, choices=TIPO_ANOTACION_CHOICES)
    descripcion = models.TextField()
    fecha = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Anotación {self.tipo} para {self.alumno} en {self.asignatura}"

# Modelo de Notas
class Nota(models.Model):
    alumno = models.ForeignKey(Alumno, on_delete=models.CASCADE)
    asignatura = models.ForeignKey(Asignatura, on_delete=models.CASCADE)
    evaluacion = models.IntegerField()  # Número de la evaluación (1, 2, 3, ...)
    nota = models.CharField(max_length=4)  # Cambiado a CharField
    semestre = models.ForeignKey('Semestre', on_delete=models.SET_NULL, null=True)

    class Meta:
        unique_together = ('alumno', 'asignatura', 'evaluacion')

    def __str__(self):
        return f"Nota {self.nota} - Evaluación {self.evaluacion} - {self.alumno}"



# Modelo de Asistencia
class Asistencia(models.Model):
    alumno = models.ForeignKey(Alumno, on_delete=models.CASCADE)
    asignatura = models.ForeignKey(Asignatura, on_delete=models.CASCADE)
    fecha = models.DateTimeField(auto_now_add=True)
    presente = models.BooleanField()
    semestre = models.ForeignKey('Semestre', on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return f"Asistencia {self.alumno} - {self.asignatura}"

# Modelo de Semestre
class Semestre(models.Model):
    nombre = models.CharField(max_length=50)
    inicio = models.DateField()
    fin = models.DateField()
    ano_escolar = models.ForeignKey('AnoEscolar', on_delete=models.CASCADE)

    def __str__(self):
        return self.nombre

# Modelo de Año Escolar
class AnoEscolar(models.Model):
    nombre = models.CharField(max_length=50)

    def __str__(self):
        return self.nombre

