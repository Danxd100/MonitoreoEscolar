from django import forms
from django.forms import DateInput

from .models import Curso, AnoEscolar, Semestre, Asignatura, Alumno, Usuario, Asistencia

#from .models import Asignatura

class AnoForm(forms.ModelForm):
    class Meta:
        model = AnoEscolar
        fields = ['nombre']

class SemestreForm(forms.ModelForm):
    class Meta:
        model = Semestre
        fields = ['nombre','inicio','fin','ano_escolar']
        widgets = {
            'inicio': DateInput(attrs={'type': 'date'}),
            'fin': DateInput(attrs={'type': 'date'}),
        }

class CursoForm(forms.ModelForm):
    class Meta:
        model = Curso
        fields = ['nombre','semestre']

class AsignaturaForm(forms.ModelForm):
    class Meta:
        model = Asignatura
        fields = ['nombre', 'curso', 'semestre']

class AlumnoForm(forms.ModelForm):
    class Meta:
        model = Alumno
        fields = ['rut', 'primer_nombre', 'segundo_nombre', 'appaterno', 'apmaterno', 'curso', 'apoderado']
        exclude = ['apoderado']

class ProfesorForm(forms.ModelForm):
    password1 = forms.CharField(label='Contraseña', widget=forms.PasswordInput)
    password2 = forms.CharField(label='Confirmar Contraseña', widget=forms.PasswordInput)
    asignatura = forms.ModelChoiceField(queryset=Asignatura.objects.all(), label="Asignatura", required=True)
    es_jefe = forms.BooleanField(label="Es Profesor Jefe", required=False)

    class Meta:
        model = Usuario
        fields = ['rut', 'primer_nombre', 'segundo_nombre', 'appaterno', 'apmaterno']  # Eliminamos 'tipo' del formulario

    def clean_password2(self):
        password1 = self.cleaned_data.get("password1")
        password2 = self.cleaned_data.get("password2")
        if password1 and password2 and password1 != password2:
            raise forms.ValidationError("Las contraseñas no coinciden.")
        return password2

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password1"])
        user.tipo = 'profesor'  # Establecemos automáticamente que el tipo sea 'profesor'
        if commit:
            user.save()
        return user


class ApoderadoForm(forms.ModelForm):
    password1 = forms.CharField(label='Contraseña', widget=forms.PasswordInput)
    password2 = forms.CharField(label='Confirmar Contraseña', widget=forms.PasswordInput)

    class Meta:
        model = Usuario
        fields = ['rut', 'primer_nombre', 'segundo_nombre', 'appaterno', 'apmaterno']  # Eliminamos 'tipo'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['tipo'] = forms.CharField(initial='apoderado', widget=forms.HiddenInput())  # Predeterminado y oculto

    def clean_password2(self):
        password1 = self.cleaned_data.get("password1")
        password2 = self.cleaned_data.get("password2")
        if password1 and password2 and password1 != password2:
            raise forms.ValidationError("Las contraseñas no coinciden.")
        return password2

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password1"])
        user.tipo = 'apoderado'  # Asignar tipo directamente
        if commit:
            user.save()
        return user


class AsistenciaForm(forms.ModelForm):
    class Meta:
        model = Asistencia
        fields = ['presente']  # Solo necesitamos la columna 'presente' para el formulario
