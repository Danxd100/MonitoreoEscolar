from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.http import HttpResponseRedirect
from django.contrib.contenttypes.models import ContentType
from django.contrib.auth import authenticate, login

from .forms import CursoForm, SemestreForm, AnoForm, AsignaturaForm
from .models import Curso, Semestre, AnoEscolar, Asignatura

from django.shortcuts import render, get_object_or_404, redirect

""" 
from .forms import AsignaturaForm
"""
# Verificar si el usuario es administrador
def es_administrador(user):
    if user.is_superuser or user.is_staff:
        return True
    return HttpResponseRedirect('/')  


def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            # Verificamos si el usuario es admin y redirigimos a la página correspondiente
            if user.is_superuser or user.is_staff:
                return redirect('registroadmin.html')  # Redirige a la página de administrador
            else:
                return redirect('registro.html')  # Redirige a la página principal si no es admin
        else:
            return render(request, 'login.html', {'error': 'Credenciales incorrectas'})
    
    return render(request, 'login.html')


def registro(request):

    return render(request, 'registro.html')


@user_passes_test(es_administrador)  # Restringir acceso solo a administradores
@login_required  # Asegura que esté autenticado
def registroadmin(request):

    return render(request, 'registroadmin.html')
"""
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
"""
# Vista para crear Año Escolar, Semestre y Curso
def crear_curso(request):
    # Inicializar los formularios
    ano_form = AnoForm(request.POST or None)
    semestre_form = SemestreForm(request.POST or None)
    curso_form = CursoForm(request.POST or None)

    # Manejar la lógica del formulario basado en el botón que se presionó
    if request.method == 'POST':
        if 'guardar_ano' in request.POST and ano_form.is_valid():
            ano_form.save()
            return redirect('crear_curso')  # Redirigir después de guardar

        elif 'guardar_semestre' in request.POST and semestre_form.is_valid():
            semestre_form.save()
            return redirect('crear_curso')  # Redirigir después de guardar

        elif 'guardar_curso' in request.POST and curso_form.is_valid():
            curso_form.save()
            return redirect('crear_curso')  # Redirigir después de guardar

    # Pasar formularios al contexto
    return render(request, 'crear_curso.html', {
        'ano_form': ano_form,
        'semestre_form': semestre_form,
        'curso_form': curso_form,
        'anoescolares': AnoEscolar.objects.all(),  # Obtener años escolares para mostrar en la plantilla
        'semestres': Semestre.objects.all(),  # Obtener semestres si es necesario
        'cursos': Curso.objects.all()  # Obtener cursos si es necesario
    })

# Vista para eliminar
def eliminar_objeto(request, model_name, id_objeto):
    model_mapping = {
        'anoescolar': AnoEscolar,
        'semestre': Semestre,
        'curso': Curso,
        'asignatura': Asignatura,  # Agrega Asignatura aquí
    }
    
    model_class = model_mapping.get(model_name)

    if model_class:
        objeto = get_object_or_404(model_class, id=id_objeto)
        objeto.delete()

        # Redirige según el tipo de objeto eliminado
        if model_name == 'asignatura':
            return redirect('crear_asignatura')  # Redirige a la página de asignaturas
        elif model_name == 'curso':
            return redirect('crear_curso')  # Redirige a la página de cursos
        elif model_name == 'anoescolar':
            return redirect('crear_curso')  # Redirige a la página de año escolar
        elif model_name == 'semestre':
            return redirect('crear_curso')  # Redirige a la página de semestre

    return redirect('registroadmin')  # Redirección por defecto

"""
------------------------------------------------------------------------------------------------------------------------------------------------------
"""
# Vista para crear Asignatura
def crear_asignatura(request):
    if request.method == 'POST':
        asignatura_form = AsignaturaForm(request.POST)
        if asignatura_form.is_valid():
            asignatura_form.save()
            return redirect('crear_asignatura')
    else:
        asignatura_form = AsignaturaForm()

    # Obtener listas de cursos y semestres si es necesario
    cursos = Curso.objects.all()
    semestres = Semestre.objects.all()
    asignaturas = Asignatura.objects.all()  # Opcional, si quieres mostrar las asignaturas existentes

    return render(request, 'crear_asignatura.html', {
        'asignatura_form': asignatura_form,
        'cursos': cursos,
        'semestres': semestres,
        'asignaturas': asignaturas,
    })

# Vista para modificar
def modificar_objeto(request, model_name, id_objeto):
    model_mapping = {
        'anoescolar': (AnoEscolar, AnoForm),
        'semestre': (Semestre, SemestreForm),
        'curso': (Curso, CursoForm),
        'asignatura': (Asignatura, AsignaturaForm), 
    }

    model_class, form_class = model_mapping.get(model_name)

    if model_class and form_class:
        objeto = get_object_or_404(model_class, id=id_objeto)

        if request.method == 'POST':
            form = form_class(request.POST, instance=objeto)
            if form.is_valid():
                form.save()
                if model_name == 'asignatura':
                    return redirect('crear_asignatura')  # Redirige a la página de asignaturas
                elif model_name == 'curso':
                    return redirect('crear_curso')  # Redirige a la página de cursos
                elif model_name == 'anoescolar':
                    return redirect('crear_curso')  # Redirige a la página de año escolar
                elif model_name == 'semestre':
                    return redirect('crear_curso')  # Redirige a la página de semestre
                return redirect('registroadmin')
        else:
            form = form_class(instance=objeto)

        return render(request, 'modificar_objeto.html', {'form': form, 'model_name': model_name})

    return redirect('registroadmin')

"""""
def modificar_asignatura(request, id_objeto):
    model_name = 'asignatura'  # Indica el modelo que estás modificando
    model_mapping = {
        'asignatura': (Asignatura, AsignaturaForm),
    }

    model_class, form_class = model_mapping.get(model_name)
    objeto = get_object_or_404(model_class, id=id_objeto)

    if request.method == 'POST':
        form = form_class(request.POST, instance=objeto)
        if form.is_valid():
            form.save()
            return redirect('crear_asignatura')
    else:
        form = form_class(instance=objeto)

    return render(request, 'modificar_objeto.html', {'form': form, 'model_name': model_name})

def eliminar_asignatura(request, id_objeto):
    asignatura = get_object_or_404(Asignatura, id=id_objeto)

    if request.method == 'POST':
        asignatura.delete()
        return redirect('crear_asignatura')

    return render(request, 'eliminar_asignatura.html', {
        'asignatura': asignatura,
    })
    """