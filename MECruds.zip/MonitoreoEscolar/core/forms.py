from django import forms
from django.forms import DateInput

from .models import Curso, AnoEscolar, Semestre, Asignatura

#from .models import Asignatura

class AnoForm(forms.ModelForm):
    class Meta:
        model = AnoEscolar
        fields = ['nombre']

class SemestreForm(forms.ModelForm):
    class Meta:
        model = Semestre
        fields = ['nombre','inicio','fin','ano_escolar']
        widgets = {
            'inicio': DateInput(attrs={'type': 'date'}),
            'fin': DateInput(attrs={'type': 'date'}),
        }

class CursoForm(forms.ModelForm):
    class Meta:
        model = Curso
        fields = ['nombre','semestre']

class AsignaturaForm(forms.ModelForm):
    class Meta:
        model = Asignatura
        fields = ['nombre', 'curso', 'semestre']


