from django.urls import path
from django.contrib.auth import views as auth_views

from .views import *
from . import views

urlpatterns = [
    path('', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('registro.html', registro, name='registro'),
    path('registroadmin.html', registroadmin, name='registroadmin'),

    path('crear_curso/', views.crear_curso, name='crear_curso'),
    path('eliminar/<str:model_name>/<int:id_objeto>/', views.eliminar_objeto, name='eliminar_objeto'),
    path('modificar/<str:model_name>/<int:id_objeto>/', views.modificar_objeto, name='modificar_objeto'),

    path('crear_asignatura/', crear_asignatura, name='crear_asignatura'),
    
]
