from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.http import HttpResponseRedirect, HttpResponseBadRequest
from django.contrib.contenttypes.models import ContentType
from django.contrib.auth import authenticate, login

from .forms import CursoForm, SemestreForm, AnoForm, AsignaturaForm, AlumnoForm, ProfesorForm, ApoderadoForm
from .models import Curso, Semestre, AnoEscolar, Asignatura, Alumno, Usuario, Profesor, Asistencia, Anotacion, Nota

from django.shortcuts import render, get_object_or_404, redirect

from django.contrib.auth import authenticate, login as auth_login

from django.urls import reverse
from django import template
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login as auth_login
from django.http import HttpResponseRedirect
from django.utils import timezone
from datetime import datetime
from django.utils.timezone import make_aware, is_naive

from django.db.models import DateField
from django.db.models.functions import TruncDate
from django.contrib import messages

def login_view(request):
    if request.method == 'POST':
        rut = request.POST.get('rut')  # Usamos RUT
        password = request.POST.get('password')
        
        # Autenticamos con RUT como el nombre de usuario
        user = authenticate(request, username=rut, password=password)
        
        if user is not None:
            auth_login(request, user)
            
            # Verificar si el usuario es superuser o staff y redirigir en consecuencia
            if user.is_superuser or user.is_staff:
                return redirect('registroadmin')  # Redirige a la página de administrador
            elif user.tipo == 'profesor':
                return redirect('registro')  # Redirige a la página de profesor
            elif user.tipo == 'apoderado':
                return redirect('registro')  # Redirige a la página de apoderado
            else:
                return redirect('login.html')  # Redirige a la página principal para usuarios normales
        else:
            return render(request, 'login.html', {'error': 'RUT o contraseña incorrectos'})
    
    return render(request, 'login.html')


@login_required
def registro_view(request):

    return render(request, 'registro.html')

@login_required
@user_passes_test(lambda u: u.is_superuser or u.is_staff)
def registroadmin_view(request):

    return render(request, 'registroadmin.html')
"""
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
"""
# Vista para crear Año Escolar, Semestre y Curso
def crear_curso(request):
    # Inicializar los formularios
    ano_form = AnoForm(request.POST or None)
    semestre_form = SemestreForm(request.POST or None)
    curso_form = CursoForm(request.POST or None)

    # Manejar la lógica del formulario basado en el botón que se presionó
    if request.method == 'POST':
        if 'guardar_ano' in request.POST and ano_form.is_valid():
            ano_form.save()
            return redirect('crear_curso')  # Redirigir después de guardar

        elif 'guardar_semestre' in request.POST and semestre_form.is_valid():
            semestre_form.save()
            return redirect('crear_curso')  # Redirigir después de guardar

        elif 'guardar_curso' in request.POST and curso_form.is_valid():
            curso_form.save()
            return redirect('crear_curso')  # Redirigir después de guardar

    # Pasar formularios al contexto
    return render(request, 'crear_curso.html', {
        'ano_form': ano_form,
        'semestre_form': semestre_form,
        'curso_form': curso_form,
        'anoescolares': AnoEscolar.objects.all(),  # Obtener años escolares para mostrar en la plantilla
        'semestres': Semestre.objects.all(),  # Obtener semestres si es necesario
        'cursos': Curso.objects.all()  # Obtener cursos si es necesario
    })

# Vista para crear Asignatura
def crear_asignatura(request):
    if request.method == 'POST':
        asignatura_form = AsignaturaForm(request.POST)
        if asignatura_form.is_valid():
            asignatura_form.save()
            return redirect('crear_asignatura')
    else:
        asignatura_form = AsignaturaForm()

    # Obtener listas de cursos y semestres si es necesario
    cursos = Curso.objects.all()
    semestres = Semestre.objects.all()
    asignaturas = Asignatura.objects.all()  # Opcional, si quieres mostrar las asignaturas existentes

    return render(request, 'crear_asignatura.html', {
        'asignatura_form': asignatura_form,
        'cursos': cursos,
        'semestres': semestres,
        'asignaturas': asignaturas,
    })

# Vista para crear Alumno
@login_required
@user_passes_test(lambda u: u.is_superuser or u.is_staff)
def crear_alumno(request):
    # Inicializamos el formulario de apoderado
    apoderado_form = ApoderadoForm()

    if request.method == 'POST':
        if 'guardar_alumno' in request.POST:
            alumno_form = AlumnoForm(request.POST)
            apoderado_id = request.POST.get('apoderado_id')  # Obtenemos el ID del apoderado automáticamente

            if alumno_form.is_valid() and apoderado_id:
                # Creamos el objeto alumno pero no lo guardamos aún
                alumno = alumno_form.save(commit=False)
                # Asignamos el apoderado al alumno utilizando el ID
                alumno.apoderado = Usuario.objects.get(id=apoderado_id)
                alumno.save()
                return redirect('crear_alumno')  # Redirigir para evitar reenvío del formulario

        elif 'guardar_apoderado' in request.POST:
            apoderado_form = ApoderadoForm(request.POST)
            if apoderado_form.is_valid():
                apoderado_form.save()
                return redirect('crear_alumno')

    else:
        # Inicializamos los formularios si es un GET
        alumno_form = AlumnoForm()

    return render(request, 'crear_alumno.html', {
        'alumno_form': alumno_form,
        'apoderado_form': apoderado_form,
        'apoderados': Usuario.objects.filter(tipo='apoderado'),  # Solo mostrar apoderados
        'alumnos': Alumno.objects.all(),  # Mostrar alumnos existentes
    })


def crear_profesor(request):
    if request.method == 'POST':
        profesor_form = ProfesorForm(request.POST)
        if profesor_form.is_valid():
            usuario_profesor = profesor_form.save()  # Guardamos el profesor como usuario
            asignatura = profesor_form.cleaned_data.get('asignatura')  # Obtenemos la asignatura seleccionada
            es_jefe = profesor_form.cleaned_data.get('es_jefe')  # Obtenemos si es profesor jefe
            # Creamos la relación entre el usuario y la asignatura en la tabla Profesor, y si es jefe
            Profesor.objects.create(usuario=usuario_profesor, asignatura=asignatura, es_jefe=es_jefe)
            return redirect('crear_profesor')  # Redirige a la misma página después de crear el profesor
    else:
        profesor_form = ProfesorForm()

    profesores = Usuario.objects.filter(tipo='profesor')  # Solo trae los usuarios que son profesores

    return render(request, 'crear_profesor.html', {'profesor_form': profesor_form, 'profesores': profesores})


"""
------------------------------------------------------------------------------------------------------------------------------------------------------
"""

# Vista para modificar
@login_required
def modificar_objeto(request, model_name, id_objeto):
    model_mapping = {
        'anoescolar': (AnoEscolar, AnoForm),
        'semestre': (Semestre, SemestreForm),
        'curso': (Curso, CursoForm),
        'asignatura': (Asignatura, AsignaturaForm),
        'alumno': (Alumno, AlumnoForm),
        'profesor': (Usuario, ProfesorForm),
        'apoderado':(Usuario, ApoderadoForm), 
    }

    model_class, form_class = model_mapping.get(model_name)

    if model_class and form_class:
        objeto = get_object_or_404(model_class, id=id_objeto)

        if request.method == 'POST':
            form = form_class(request.POST, instance=objeto)
            if form.is_valid():
                form.save()
                if model_name == 'asignatura':
                    return redirect('crear_asignatura')  # Redirige a la página de asignaturas
                elif model_name == 'curso':
                    return redirect('crear_curso')  # Redirige a la página de cursos
                elif model_name == 'anoescolar':
                    return redirect('crear_curso')  # Redirige a la página de año escolar
                elif model_name == 'semestre':
                    return redirect('crear_curso')  # Redirige a la página de semestre
                elif model_name == 'alumno':
                    return redirect('crear_alumno')  # Redirige a la página de alumnos
                elif model_name == 'profesor':
                    return redirect('crear_profesor')  # Redirige a la página de profesores
                elif model_name == 'apoderado':
                    return redirect('crear_alumno')  # Redirige a la página de apoderados
                return redirect('registroadmin')
        else:
            form = form_class(instance=objeto)
        return render(request, 'modificar_objeto.html', {'form': form, 'model_name': model_name})
    return redirect('registroadmin')

# Vista para eliminar
@login_required
def eliminar_objeto(request, model_name, id_objeto):
    model_mapping = {
        'anoescolar': AnoEscolar,
        'semestre': Semestre,
        'curso': Curso,
        'asignatura': Asignatura,
        'alumno': Alumno, 
        'profesor': Usuario,
        'apoderado':Usuario,  
    }
    
    model_class = model_mapping.get(model_name)

    if model_class:
        objeto = get_object_or_404(model_class, id=id_objeto)
        objeto.delete()

        # Redirige según el tipo de objeto eliminado
        if model_name == 'asignatura':
            return redirect('crear_asignatura')  # Redirige a la página de asignaturas
        elif model_name == 'curso':
            return redirect('crear_curso')  # Redirige a la página de cursos
        elif model_name == 'anoescolar':
            return redirect('crear_curso')  # Redirige a la página de año escolar
        elif model_name == 'semestre':
            return redirect('crear_curso')  # Redirige a la página de semestre
        elif model_name == 'alumno':
            return redirect('crear_alumno')  # Redirige a la página de alumnos
        elif model_name == 'profesor':
            return redirect('crear_profesor')  # Redirige a la página de profesores
        elif model_name == 'apoderado':
            return redirect('crear_alumno')  # Redirige a la página de apoderados
    return redirect('registroadmin')  # Redirección por defecto



@login_required
def ver_notas_view(request):

    return render(request, 'ver_notas.html')


@login_required
def ver_asistencias_view(request):
    # Verifica que el usuario sea un apoderado
    if request.user.tipo == 'apoderado':
        # Encuentra a los alumnos relacionados con el apoderado
        alumnos = Alumno.objects.filter(apoderado=request.user)
        
        # Busca las asistencias de los alumnos
        asistencias_por_alumno = {}
        for alumno in alumnos:
            asistencias = Asistencia.objects.filter(alumno=alumno)
            asistencias_por_alumno[alumno] = asistencias

        return render(request, 'ver_asistencias.html', {
            'asistencias_por_alumno': asistencias_por_alumno,
        })
    else:
        return redirect('login')  # Si no es apoderado, redirige a login

@login_required
def ver_anotaciones_view(request):
    # Verifica que el usuario sea un apoderado
    if request.user.tipo == 'apoderado':
        # Encuentra a los alumnos relacionados con el apoderado
        alumnos = Alumno.objects.filter(apoderado=request.user)
        
        # Busca las anotaciones de los alumnos
        anotaciones_por_alumno = {}
        for alumno in alumnos:
            anotaciones = Anotacion.objects.filter(alumno=alumno).order_by('-fecha')
            anotaciones_por_alumno[alumno] = anotaciones

        return render(request, 'ver_anotaciones.html', {
            'anotaciones_por_alumno': anotaciones_por_alumno,
        })
    else:
        return redirect('login')  # Si no es apoderado, redirige a login




@login_required
def ver_asistencias_profesor_view(request):
    # Obtenemos las asignaturas que imparte el profesor
    asignaturas = Asignatura.objects.filter(profesor__usuario=request.user)
    
    # Crear una lista de asignaturas con sus cursos para el combo box
    cursos_con_asignaturas = [
        {
            'id': asignatura.id,
            'nombre': f"{asignatura.nombre} - {asignatura.curso.nombre}"
        }
        for asignatura in asignaturas
    ]

    # Obtener la asignatura seleccionada del request
    asignatura_id = request.GET.get('curso')
    asignatura_seleccionada = get_object_or_404(asignaturas, id=asignatura_id) if asignatura_id else None

    # Filtrar las asistencias según la asignatura seleccionada
    if asignatura_seleccionada:
        asistencias = Asistencia.objects.filter(asignatura=asignatura_seleccionada)
    else:
        asistencias = Asistencia.objects.none()  # Devuelve un queryset vacío si no hay asignatura seleccionada

    # Obtener las fechas únicas de las asistencias
    fechas_con_asistencias = (
        asistencias.annotate(fecha_registro=TruncDate('fecha'))
        .values('fecha_registro')
        .distinct()
    )

    # Verificación de si hay una asistencia registrada para hoy en la zona horaria local
    fecha_hoy = timezone.localtime(timezone.now()).date()
    asistencia_hoy = asistencias.filter(fecha__date=fecha_hoy).exists()

    context = {
        'cursos_con_asignaturas': cursos_con_asignaturas,
        'asignatura_seleccionada': asignatura_seleccionada,
        'fechas_con_asistencias': fechas_con_asistencias,
        'asistencia_hoy': asistencia_hoy
    }
    return render(request, 'ver_asistencias_profesor.html', context)



@login_required
def agregar_asistencias_view(request, fecha):
    # Convertimos la fecha recibida a un formato adecuado
    if fecha == 'hoy':
        fecha = timezone.localtime(timezone.now()).date()
    else:
        fecha = datetime.strptime(fecha, '%Y-%m-%d').date()

    # Obtener la asignatura seleccionada del request
    asignatura_id = request.GET.get('curso')  # Aquí 'curso' se refiere al ID de la asignatura.
    if not asignatura_id:
        return HttpResponseBadRequest("No se ha especificado una asignatura para la asistencia.")

    # Obtener la asignatura y curso asociados
    asignatura = get_object_or_404(Asignatura, id=asignatura_id)
    curso = asignatura.curso
    alumnos = Alumno.objects.filter(curso=curso)

    # Recuperamos asistencias ya registradas para la fecha si existen
    asistencias_registradas = Asistencia.objects.filter(
        asignatura=asignatura, fecha__date=fecha
    )

    # Convertimos las asistencias registradas a un diccionario para acceder rápidamente
    asistencias_dict = {
        asistencia.alumno.id: asistencia
        for asistencia in asistencias_registradas
    }

    if request.method == 'POST':
        for alumno in alumnos:
            presente = request.POST.get(f'presente_{alumno.id}', 'false') == 'true'
            semestre = asignatura.semestre

            asistencia = asistencias_dict.get(alumno.id)

            if asistencia:
                asistencia.presente = presente
                asistencia.semestre = semestre
                asistencia.save()
            else:
                Asistencia.objects.create(
                    alumno=alumno,
                    asignatura=asignatura,
                    fecha=make_aware(datetime.combine(fecha, datetime.min.time())),
                    presente=presente,
                    semestre=semestre
                )

        messages.success(request, "La asistencia ha sido actualizada exitosamente.")
        return redirect(f'{reverse("ver_asistencias_profesor")}?curso={asignatura_id}')

    context = {
        'fecha': fecha,
        'alumnos': alumnos,
        'curso': curso,
        'alumnos_presentes': [a.alumno for a in asistencias_registradas if a.presente]
    }
    return render(request, 'agregar_asistencias.html', context)




@login_required
def ver_anotaciones_profesores_view(request):
    # Obtenemos las asignaturas que imparte el profesor
    asignaturas = Asignatura.objects.filter(profesor__usuario=request.user)
    
    # Crear una lista de asignaturas con sus cursos para el combo box
    cursos_con_asignaturas = [
        {
            'id': asignatura.id,
            'nombre': f"{asignatura.nombre} - {asignatura.curso.nombre}"
        }
        for asignatura in asignaturas
    ]

    # Obtener la asignatura seleccionada del request
    asignatura_id = request.GET.get('curso')
    asignatura_seleccionada = get_object_or_404(asignaturas, id=asignatura_id) if asignatura_id else None

    # Filtrar las anotaciones según la asignatura seleccionada
    if asignatura_seleccionada:
        alumnos = Alumno.objects.filter(curso=asignatura_seleccionada.curso)
        anotaciones = Anotacion.objects.filter(alumno__in=alumnos, asignatura=asignatura_seleccionada).order_by('-fecha')
    else:
        alumnos = []
        anotaciones = []

    context = {
        'cursos_con_asignaturas': cursos_con_asignaturas,
        'asignatura_seleccionada': asignatura_seleccionada,
        'alumnos': alumnos,
        'anotaciones': anotaciones,
    }
    return render(request, 'ver_anotaciones_profesores.html', context)






@login_required
def agregar_anotaciones_view(request, anotacion_id=None):
    # Usar la fecha de hoy según la zona horaria local
    fecha = timezone.localtime(timezone.now()).date()

    # Obtener la asignatura seleccionada del request
    asignatura_id = request.GET.get('curso')
    if not asignatura_id:
        return HttpResponseBadRequest("No se ha especificado una asignatura para la anotación.")

    asignatura = get_object_or_404(Asignatura, id=asignatura_id)
    curso = asignatura.curso
    alumnos = Alumno.objects.filter(curso=curso)

    # Si se proporciona un anotacion_id, obtener la anotación específica
    anotacion = None
    if anotacion_id:
        anotacion = get_object_or_404(Anotacion, id=anotacion_id, alumno__curso=curso)

    if request.method == 'POST':
        # Si hay una anotación existente, actualizamos la información
        if anotacion:
            descripcion = request.POST.get('descripcion', '').strip()
            tipo = request.POST.get('tipo', 'negativa')

            if descripcion:
                anotacion.descripcion = descripcion
                anotacion.tipo = tipo
                anotacion.save()
                messages.success(request, "La anotación ha sido actualizada exitosamente.")
            else:
                messages.error(request, "La descripción no puede estar vacía.")

        # Si no hay una anotación específica, permitir agregar una nueva
        else:
            for alumno in alumnos:
                descripcion = request.POST.get(f'descripcion_{alumno.id}', '').strip()
                tipo = request.POST.get(f'tipo_{alumno.id}', 'negativa')

                if descripcion:
                    Anotacion.objects.create(
                        alumno=alumno,
                        asignatura=asignatura,
                        fecha=make_aware(datetime.combine(fecha, datetime.min.time())),
                        descripcion=descripcion,
                        tipo=tipo
                    )

            messages.success(request, "Las anotaciones han sido registradas exitosamente.")

        return redirect(f'{reverse("ver_anotaciones_profesores")}?curso={asignatura_id}')

    # Preparar el contexto para la plantilla
    context = {
        'fecha': fecha,
        'alumnos': alumnos,
        'curso': curso,
        'asignatura': asignatura,
        'anotacion': anotacion,  # Pasar la anotación si se está editando
    }
    return render(request, 'agregar_anotaciones.html', context)






@login_required
def agregar_notas_view(request):
    # Obtener las asignaturas que el profesor puede seleccionar
    asignaturas = Asignatura.objects.filter(profesor__usuario=request.user)
    cursos_con_asignaturas = [
        {
            'id': asignatura.id,
            'nombre': f"{asignatura.nombre} - {asignatura.curso.nombre}"
        }
        for asignatura in asignaturas
    ]

    # Obtener la asignatura seleccionada del request
    asignatura_id = request.GET.get('curso')
    asignatura_seleccionada = get_object_or_404(asignaturas, id=asignatura_id) if asignatura_id else None
    curso_seleccionado = asignatura_seleccionada.curso if asignatura_seleccionada else None

    # Definir un rango inicial de evaluaciones (por ejemplo, 1 a 4)
    rango_evaluaciones = range(1, 5)

    # Filtrar alumnos del curso seleccionado
    alumnos = Alumno.objects.filter(curso=curso_seleccionado) if curso_seleccionado else []

    # Recuperar notas existentes
    notas_dict = {}
    if curso_seleccionado:
        notas = Nota.objects.filter(alumno__in=alumnos, asignatura=asignatura_seleccionada)
        for nota in notas:
            notas_dict.setdefault(nota.alumno.id, {})[nota.id] = nota.nota

    if request.method == 'POST':
        for alumno in alumnos:
            for i in rango_evaluaciones:
                nota_key = f'nota_{alumno.id}_{i}'
                valor_nota = request.POST.get(nota_key)

                # Si hay una nota, intentamos crearla o actualizarla
                if valor_nota:
                    try:
                        valor_nota = float(valor_nota)
                        if 1.0 <= valor_nota <= 7.0:
                            nota, created = Nota.objects.get_or_create(
                                alumno=alumno,
                                asignatura=asignatura_seleccionada,
                                semestre=curso_seleccionado.semestre,
                                defaults={'nota': valor_nota}
                            )
                            if not created:
                                nota.nota = valor_nota
                                nota.save()
                        else:
                            messages.error(request, f'La nota debe estar entre 1.0 y 7.0 para {alumno.primer_nombre}.')
                    except ValueError:
                        messages.error(request, f'Valor de nota no válido para {alumno.primer_nombre}.')

        messages.success(request, "Las notas han sido guardadas exitosamente.")
        # Recuperar nuevamente las notas actualizadas para mostrar en la vista
        notas = Nota.objects.filter(alumno__in=alumnos, asignatura=asignatura_seleccionada)
        notas_dict = {}
        for nota in notas:
            notas_dict.setdefault(nota.alumno.id, {})[nota.id] = nota.nota

    context = {
        'cursos_con_asignaturas': cursos_con_asignaturas,
        'asignatura_seleccionada': asignatura_seleccionada,
        'curso_seleccionado': curso_seleccionado,
        'alumnos': alumnos,
        'rango_evaluaciones': rango_evaluaciones,
        'notas_dict': notas_dict,
    }
    return render(request, 'agregar_notas.html', context)






