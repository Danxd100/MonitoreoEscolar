from django import template
from decimal import Decimal

register = template.Library()

@register.filter
def get_item(dictionary, key):
    if dictionary is None:
        return None
    value = dictionary.get(key)
    # Convertir a float si es Decimal para que se pueda mostrar correctamente en el input
    if isinstance(value, Decimal):
        return float(value)
    return value
