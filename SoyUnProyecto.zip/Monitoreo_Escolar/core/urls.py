from django.urls import path
from django.contrib.auth import views as auth_views

from .views import *
from . import views

urlpatterns = [
    path('', login_view, name='login'),  # Usa la nueva vista de login personalizada
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('registro', registro_view, name='registro'),
    path('registroadmin', registroadmin_view, name='registroadmin'),

    path('crear_curso/', views.crear_curso, name='crear_curso'),
    path('crear_asignatura/', crear_asignatura, name='crear_asignatura'),
    path('crear_alumno/', views.crear_alumno, name='crear_alumno'),
    path('crear_alumno/<int:apoderado_id>/', crear_alumno, name='crear_alumno'),  # Para agregar alumno a un apoderado específico
    path('crear_profesor/', crear_profesor, name='crear_profesor'),

    path('eliminar/<str:model_name>/<int:id_objeto>/', views.eliminar_objeto, name='eliminar_objeto'),
    path('modificar/<str:model_name>/<int:id_objeto>/', views.modificar_objeto, name='modificar_objeto'),

    path('ver_notas_apoderado/', ver_notas_apoderado_view, name='notas_apoderado'),
    path('anotaciones_alumno', ver_anotaciones_view, name='ver_anotaciones'),
    path('asistencias_alumno', ver_asistencias_view, name='ver_asistencias'),
    path('ver_asistencias_profesor/', ver_asistencias_profesor_view, name='ver_asistencias_profesor'),
    path('agregar_asistencias/<str:fecha>/', agregar_asistencias_view, name='agregar_asistencias'),
    path('ver_anotaciones/', ver_anotaciones_profesores_view, name='ver_anotaciones_profesores'),
    path('agregar_anotaciones/', agregar_anotaciones_view, name='agregar_anotaciones'),
    path('agregar_anotaciones/<int:anotacion_id>/', agregar_anotaciones_view, name='editar_anotacion'),
    path('ver_notas_profesor/',ver_notas_profesor_view, name='ver_notas_profesor'),
    path('agregar_notas/', agregar_notas_view, name='agregar_notas'),
    path('modificar_notas/<int:alumno_id>/<int:asignatura_id>/', modificar_notas_view, name='modificar_notas'),
    path('registro_profesor_jefe', registro_profesor_jefe_view, name='registro_profesor_jefe'),
    path('registro_curso_jefe', registro_curso_jefe_view, name='registro_curso_jefe'),

    path('ver_notas_jefe', ver_notas_jefe_view, name='ver_notas_jefe'),
    path('ver_anotaciones_jefe', ver_anotaciones_jefe_view, name='ver_anotaciones_jefe'),
    path('ver_asistencias_jefe', ver_asistencias_jefe_view, name='ver_asistencias_jefe'),

]
