from django.urls import path

from .views import *

urlpatterns = [
    path('', index,name="index"),
    path('registro.html', registro, name='registro'),
    path('registroadmin.html', registroadmin, name='registroadmin'),

]
