document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('#formAgregarNotas, #formModificarNotas');

    forms.forEach(form => {
        if (form) {
            form.addEventListener('submit', function(event) {
                const inputs = form.querySelectorAll('input[type="text"]');
                let valid = true;

                inputs.forEach(input => {
                    const value = input.value.trim().replace(',', '.');
                    const numericValue = parseFloat(value);

                    if (value !== "" && (numericValue < 1.0 || numericValue > 7.0)) {
                        showErrorToast(`La nota para el alumno debe estar entre 1,0 y 7,0.`);
                        valid = false;
                    } else if (numericValue) {
                        input.value = numericValue.toFixed(1).replace('.', ',');  // Reemplazar formato antes de enviar
                    }
                });

                if (!valid) {
                    event.preventDefault(); // Evitar que se envíe el formulario si hay errores
                }
            });

            // Formateo en tiempo real
            const inputs = form.querySelectorAll('input[type="text"]');
            inputs.forEach(input => {
                input.addEventListener('input', function() {
                    formatInput(input);
                });
            });
        }
    });
});

function formatInput(input) {
    const cursorPosition = input.selectionStart;
    let value = input.value.replace(/[^0-9]/g, '');

    if (value.length >= 2) {
        value = value.slice(0, -1) + ',' + value.slice(-1);
    }

    value = value.slice(0, 3);
    input.value = value;
    input.setSelectionRange(cursorPosition, cursorPosition);
}

function showErrorToast(message) {
    const toastContainer = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = 'toast align-items-center text-white bg-danger border-0';
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    `;
    toastContainer.appendChild(toast);
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
    toast.addEventListener('hidden.bs.toast', function() {
        toast.remove();
    });
}

document.addEventListener('DOMContentLoaded', function() {
    // Validación de formularios específicos
    const formAno = document.querySelector('form button[name="guardar_ano"]').closest('form');
    const formSemestre = document.querySelector('form button[name="guardar_semestre"]').closest('form');
    const formCurso = document.querySelector('form button[name="guardar_curso"]').closest('form');

    if (formAno) {
        formAno.addEventListener('submit', function(event) {
            const nombreAno = formAno.querySelector('input[name="nombre"]');
            if (!nombreAno.value.trim().match(/^\d{4}$/)) {
                showErrorToast('El año escolar debe ser un número de cuatro dígitos.');
                event.preventDefault();
            }
        });
    }

    if (formSemestre) {
        formSemestre.addEventListener('submit', function(event) {
            const inicio = formSemestre.querySelector('input[name="inicio"]').value;
            const fin = formSemestre.querySelector('input[name="fin"]').value;

            if (inicio && fin && new Date(inicio) > new Date(fin)) {
                showErrorToast('La fecha de inicio debe ser anterior a la fecha de fin.');
                event.preventDefault();
            }
        });
    }

    if (formCurso) {
        formCurso.addEventListener('submit', function(event) {
            const nombreCurso = formCurso.querySelector('input[name="nombre"]');
            if (nombreCurso.value.trim().length < 3) {
                showErrorToast('El nombre del curso debe tener al menos 3 caracteres.');
                event.preventDefault();
            }
        });
    }

    function showErrorToast(message) {
        const toastContainer = document.getElementById('toastContainer') || document.body;
        const toast = document.createElement('div');
        toast.className = 'toast align-items-center text-white bg-danger border-0 mb-3'; // Asegura margen inferior
        toast.setAttribute('role', 'alert');
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        `;
        toastContainer.appendChild(toast);
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();
        toast.addEventListener('hidden.bs.toast', function() {
            toast.remove();
        });
    }
    
});

