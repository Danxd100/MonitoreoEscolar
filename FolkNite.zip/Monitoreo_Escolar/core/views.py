from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.http import HttpResponseRedirect, HttpResponseBadRequest, HttpResponse
from django.contrib.contenttypes.models import ContentType
from django.contrib.auth import authenticate, login
from django.template.loader import render_to_string
from xhtml2pdf import pisa
from django.core.paginator import Paginator
from django.core.exceptions import ValidationError


from .forms import CursoForm, SemestreForm, AnoForm, AsignaturaForm, AlumnoForm, ProfesorForm, ApoderadoForm
from .models import Curso, Semestre, AnoEscolar, Asignatura, Alumno, Usuario, Profesor, Asistencia, Anotacion, Nota

from django.shortcuts import render, get_object_or_404, redirect
from django.db.models import Max, Avg, Q
from django.contrib.auth import authenticate, login as auth_login

from django.urls import reverse
from django import template
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login as auth_login
from django.http import HttpResponseRedirect
from django.utils import timezone
from datetime import datetime
from django.utils.timezone import make_aware, is_naive

from django.db.models import DateField
from django.db.models.functions import TruncDate
from django.contrib import messages
from datetime import timedelta
from django.template.loader import get_template


def login_view(request):
    if request.method == 'POST':
        rut = request.POST.get('rut')  # Usamos RUT
        password = request.POST.get('password')
        
        # Autenticamos con RUT como el nombre de usuario
        user = authenticate(request, username=rut, password=password)
        
        if user is not None:
            auth_login(request, user)
            
            # Verificar si el usuario es superuser o staff y redirigir en consecuencia
            if user.is_superuser or user.is_staff:
                return redirect('registroadmin')  # Redirige a la página de administrador
            elif user.tipo == 'profesor':
                # Verificar si el usuario es profesor jefe
                profesor_jefe = Profesor.objects.filter(usuario=user, es_jefe=True).exists()
                if profesor_jefe:
                    return redirect('registro_profesor_jefe')  # Redirige a la página de profesor jefe
                return redirect('registro')  # Redirige a la página de profesor
            elif user.tipo == 'apoderado':
                return redirect('registro')  # Redirige a la página de apoderado
            else:
                return redirect('login.html')  # Redirige a la página principal para usuarios normales
        else:
            return render(request, 'login.html', {'error': 'RUT o contraseña incorrectos'})
    
    return render(request, 'login.html')



@login_required
def registro_view(request):

    return render(request, 'registro.html')

@login_required
@user_passes_test(lambda u: u.is_superuser or u.is_staff)
def registroadmin_view(request):

    return render(request, 'registroadmin.html')
"""
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
"""
# Vista para crear Año Escolar, Semestre y Curso

@login_required
@user_passes_test(lambda u: u.is_superuser or u.is_staff)
def crear_curso(request):
    ano_form = AnoForm(request.POST if 'guardar_ano' in request.POST else None)
    semestre_form = SemestreForm(request.POST if 'guardar_semestre' in request.POST else None)
    curso_form = CursoForm(request.POST if 'guardar_curso' in request.POST else None)

    if request.method == 'POST':
        if 'guardar_ano' in request.POST:
            if ano_form.is_valid():
                ano_form.save()
                messages.success(request, 'Año escolar guardado correctamente.')
                return redirect('crear_curso')
            else:
                messages.error(request, 'Por favor corrige los errores en el formulario del Año Escolar.')

        elif 'guardar_semestre' in request.POST:
            if semestre_form.is_valid():
                semestre_form.save()
                messages.success(request, 'Semestre guardado correctamente.')
                return redirect('crear_curso')
            else:
                messages.error(request, 'Por favor corrige los errores en el formulario del Semestre.')

        elif 'guardar_curso' in request.POST:
            if curso_form.is_valid():
                curso_form.save()
                messages.success(request, 'Curso guardado correctamente.')
                return redirect('crear_curso')
            else:
                messages.error(request, 'Por favor corrige los errores en el formulario del Curso.')

    return render(request, 'crear_curso.html', {
        'ano_form': ano_form,
        'semestre_form': semestre_form,
        'curso_form': curso_form,
        'anoescolares': AnoEscolar.objects.all(),
        'semestres': Semestre.objects.all(),
        'cursos': Curso.objects.all()
    })




# Vista para crear Asignatura
def crear_asignatura(request):
    if request.method == 'POST':
        asignatura_form = AsignaturaForm(request.POST)
        if asignatura_form.is_valid():
            asignatura_form.save()
            return redirect('crear_asignatura')
    else:
        asignatura_form = AsignaturaForm()

    # Obtener listas de cursos y semestres si es necesario
    cursos = Curso.objects.all()
    semestres = Semestre.objects.all()
    asignaturas = Asignatura.objects.all()  # Opcional, si quieres mostrar las asignaturas existentes

    return render(request, 'crear_asignatura.html', {
        'asignatura_form': asignatura_form,
        'cursos': cursos,
        'semestres': semestres,
        'asignaturas': asignaturas,
    })

@login_required
@user_passes_test(lambda u: u.is_superuser or u.is_staff)
def crear_alumno(request):
    apoderado_form = ApoderadoForm()
    alumno_form = AlumnoForm()

    if request.method == 'POST':
        if 'guardar_alumno' in request.POST:
            alumno_form = AlumnoForm(request.POST)
            apoderado_id = request.POST.get('apoderado_id')

            if alumno_form.is_valid() and apoderado_id:
                alumno = alumno_form.save(commit=False)
                alumno.apoderado = Usuario.objects.get(id=apoderado_id)
                alumno.save()

                curso = alumno.curso
                asignaturas = Asignatura.objects.filter(curso=curso)
                for asignatura in asignaturas:
                    max_evaluacion = Nota.objects.filter(asignatura=asignatura).aggregate(Max('evaluacion'))['evaluacion__max'] or 0
                    for evaluacion in range(1, max_evaluacion + 1):
                        Nota.objects.create(
                            alumno=alumno,
                            asignatura=asignatura,
                            evaluacion=evaluacion,
                            nota="-",
                            semestre=curso.semestre
                        )

                messages.success(request, "El alumno ha sido agregado exitosamente con notas vacías.")
                return redirect('crear_alumno') 

        elif 'guardar_apoderado' in request.POST:
            apoderado_form = ApoderadoForm(request.POST)
            if apoderado_form.is_valid():
                apoderado_form.save()
                messages.success(request, "El apoderado ha sido agregado exitosamente.")
                return redirect('crear_alumno')

    # Obtener el parámetro de búsqueda si existe
    search_query = request.GET.get('search', '')

    # Filtrar apoderados si hay una búsqueda
    if search_query:
        apoderados = Usuario.objects.filter(tipo='apoderado').filter(
            Q(primer_nombre__icontains=search_query) | Q(appaterno__icontains=search_query) | Q(rut__icontains=search_query)
        )
    else:
        apoderados = Usuario.objects.filter(tipo='apoderado')

    # Paginación
    paginator = Paginator(apoderados, 5)  # Dividir en páginas de 5 apoderados
    page_number = request.GET.get('page')
    apoderados_page = paginator.get_page(page_number)

    return render(request, 'crear_alumno.html', {
        'alumno_form': alumno_form,
        'apoderado_form': apoderado_form,
        'apoderados': apoderados_page,
        'alumnos': Alumno.objects.all(),
        'search_query': search_query,  # Pasar la consulta de búsqueda al contexto
    })


# En views.py
def crear_profesor(request):
    if request.method == 'POST':
        profesor_form = ProfesorForm(request.POST)
        if profesor_form.is_valid():
            usuario_profesor = profesor_form.save(commit=False)
            usuario_profesor.tipo = 'profesor'
            usuario_profesor.save()

            # Crear o actualizar el objeto Profesor
            profesor = Profesor.objects.create(
                usuario=usuario_profesor,
                es_jefe=profesor_form.cleaned_data.get('es_jefe')
            )

            # Asignar curso solo si es jefe
            if profesor.es_jefe:
                profesor.curso = profesor_form.cleaned_data.get('curso')
            else:
                profesor.curso = None  # Asegurarse de que no tiene curso si no es jefe

            # Guardar asignaturas seleccionadas
            profesor.asignatura.set(profesor_form.cleaned_data.get('asignatura'))
            profesor.save()

            return redirect('crear_profesor')
    else:
        profesor_form = ProfesorForm()

    profesores = Profesor.objects.prefetch_related('asignatura').all()

    return render(request, 'crear_profesor.html', {'profesor_form': profesor_form, 'profesores': profesores})




"""
------------------------------------------------------------------------------------------------------------------------------------------------------
"""

# Vista para modificar
@login_required
def modificar_objeto(request, model_name, id_objeto):
    model_mapping = {
        'anoescolar': (AnoEscolar, AnoForm),
        'semestre': (Semestre, SemestreForm),
        'curso': (Curso, CursoForm),
        'asignatura': (Asignatura, AsignaturaForm),
        'alumno': (Alumno, AlumnoForm),
        'profesor': (Profesor, ProfesorForm),
        'apoderado':(Usuario, ApoderadoForm), 
    }

    model_class, form_class = model_mapping.get(model_name)

    if model_class and form_class:
        objeto = get_object_or_404(model_class, id=id_objeto)

        if request.method == 'POST':
            form = form_class(request.POST, instance=objeto)
            if form.is_valid():
                form.save()
                if model_name == 'asignatura':
                    return redirect('crear_asignatura')  # Redirige a la página de asignaturas
                elif model_name == 'curso':
                    return redirect('crear_curso')  # Redirige a la página de cursos
                elif model_name == 'anoescolar':
                    return redirect('crear_curso')  # Redirige a la página de año escolar
                elif model_name == 'semestre':
                    return redirect('crear_curso')  # Redirige a la página de semestre
                elif model_name == 'alumno':
                    return redirect('crear_alumno')  # Redirige a la página de alumnos
                elif model_name == 'profesor':
                    return redirect('crear_profesor')  # Redirige a la página de profesores
                elif model_name == 'apoderado':
                    return redirect('crear_alumno')  # Redirige a la página de apoderados
                return redirect('registroadmin')
        else:
            form = form_class(instance=objeto)
        return render(request, 'modificar_objeto.html', {'form': form, 'model_name': model_name})
    return redirect('registroadmin')

# Vista para eliminar
@login_required
def eliminar_objeto(request, model_name, id_objeto):
    model_mapping = {
        'anoescolar': AnoEscolar,
        'semestre': Semestre,
        'curso': Curso,
        'asignatura': Asignatura,
        'alumno': Alumno, 
        'profesor': Profesor,
        'apoderado': Usuario,
    }
    
    model_class = model_mapping.get(model_name)

    if model_class:
        objeto = get_object_or_404(model_class, id=id_objeto)
        
        # Eliminar el usuario asociado si es un profesor
        if model_name == 'profesor':
            usuario_relacionado = objeto.usuario  # Obtén el usuario asociado al profesor
            objeto.delete()  # Elimina el profesor
            usuario_relacionado.delete()  # Elimina el usuario

            return redirect('crear_profesor')

        # Si no es un profesor, solo eliminar el objeto directamente
        objeto.delete()

        # Redirige según el tipo de objeto eliminado
        if model_name == 'asignatura':
            return redirect('crear_asignatura')
        elif model_name == 'curso':
            return redirect('crear_curso')
        elif model_name == 'anoescolar':
            return redirect('crear_curso')
        elif model_name == 'semestre':
            return redirect('crear_curso')
        elif model_name == 'alumno':
            return redirect('crear_alumno')
        elif model_name == 'apoderado':
            return redirect('crear_alumno')
    return redirect('registroadmin')

@login_required
def ver_notas_view(request):

    return render(request, 'ver_notas.html')

@login_required
def ver_asistencias_view(request):
    # Verifica que el usuario sea un apoderado
    if request.user.tipo == 'apoderado':
        # Encuentra a los alumnos relacionados con el apoderado
        alumnos = Alumno.objects.filter(apoderado=request.user)
        
        # Obtener el alumno seleccionado desde el request
        alumno_id = request.GET.get('alumno')
        alumno_seleccionado = None
        asistencias = None
        semanas = []
        semana_seleccionada = None

        if alumno_id:
            alumno_seleccionado = get_object_or_404(alumnos, id=alumno_id)
            # Busca todas las asistencias del alumno seleccionado
            asistencias = Asistencia.objects.filter(alumno=alumno_seleccionado).order_by('-fecha')

            # Calcular las semanas disponibles a partir de las fechas de asistencia
            fechas = asistencias.values_list('fecha__date', flat=True).distinct()
            for fecha in sorted(fechas):
                inicio_semana = fecha - timedelta(days=fecha.weekday())  # Lunes de esa semana
                fin_semana = inicio_semana + timedelta(days=6)  # Domingo de esa semana
                semanas.append((inicio_semana, fin_semana))
            semanas = list(set(semanas))
            semanas.sort()

            # Filtrar asistencias por la semana seleccionada
            semana_seleccionada = request.GET.get('semana')
            if semana_seleccionada:
                inicio_semana_str, fin_semana_str = semana_seleccionada.split('_')
                inicio_semana = datetime.strptime(inicio_semana_str, '%Y-%m-%d').date()
                fin_semana = datetime.strptime(fin_semana_str, '%Y-%m-%d').date()
                asistencias = asistencias.filter(fecha__date__range=(inicio_semana, fin_semana))

        return render(request, 'ver_asistencias.html', {
            'alumnos': alumnos,
            'alumno_seleccionado': alumno_seleccionado,
            'asistencias': asistencias,
            'semanas': semanas,
            'semana_seleccionada': semana_seleccionada if alumno_seleccionado else None,
        })
    else:
        return redirect('login')  # Si no es apoderado, redirige a login

@login_required
def ver_anotaciones_view(request):
    # Verifica que el usuario sea un apoderado
    if request.user.tipo == 'apoderado':
        # Encuentra a los alumnos relacionados con el apoderado
        alumnos = Alumno.objects.filter(apoderado=request.user)
        
        # Obtener el alumno seleccionado desde el request
        alumno_id = request.GET.get('alumno')
        alumno_seleccionado = None
        anotaciones = None

        if alumno_id:
            alumno_seleccionado = get_object_or_404(alumnos, id=alumno_id)
            # Busca las anotaciones del alumno seleccionado
            anotaciones = Anotacion.objects.filter(alumno=alumno_seleccionado).order_by('-fecha')

        return render(request, 'ver_anotaciones.html', {
            'alumnos': alumnos,
            'alumno_seleccionado': alumno_seleccionado,
            'anotaciones': anotaciones,
        })
    else:
        return redirect('login')  # Si no es apoderado, redirige a login

@login_required
def ver_asistencias_profesor_view(request):
    # Obtenemos las asignaturas que imparte el profesor
    asignaturas = Asignatura.objects.filter(profesor__usuario=request.user)
    
    # Crear una lista de asignaturas con sus cursos para el combo box
    cursos_con_asignaturas = [
        {
            'id': asignatura.id,
            'nombre': f"{asignatura.nombre} - {asignatura.curso.nombre}"
        }
        for asignatura in asignaturas
    ]

    # Obtener la asignatura seleccionada del request
    asignatura_id = request.GET.get('curso')
    asignatura_seleccionada = get_object_or_404(asignaturas, id=asignatura_id) if asignatura_id else None

    # Variables para el manejo de asistencias
    semanas = []
    fechas_con_asistencias = set()
    asistencias_hoy = []
    asistencia_hoy = False
    semana_con_asistencias = False
    semana_es_pasada = False  # Indica si la semana seleccionada es anterior a la actual

    if asignatura_seleccionada:
        asistencias = Asistencia.objects.filter(asignatura=asignatura_seleccionada)
        fechas = asistencias.annotate(fecha_registro=TruncDate('fecha')).values_list('fecha_registro', flat=True).distinct()
        
        # Generar las semanas (inicio y fin)
        for fecha in sorted(fechas):
            inicio_semana = fecha - timedelta(days=fecha.weekday())  # Lunes de esa semana
            fin_semana = inicio_semana + timedelta(days=6)  # Domingo de esa semana
            semanas.append((inicio_semana, fin_semana))
        semanas = list(set(semanas))
        semanas.sort()

        # Obtener la semana seleccionada desde el combo box
        semana_seleccionada = request.GET.get('semana')
        if semana_seleccionada:
            inicio_semana_str, fin_semana_str = semana_seleccionada.split('_')
            inicio_semana = datetime.strptime(inicio_semana_str, '%Y-%m-%d').date()
            fin_semana = datetime.strptime(fin_semana_str, '%Y-%m-%d').date()
            asistencias = asistencias.filter(fecha__date__range=(inicio_semana, fin_semana))
            fechas_con_asistencias = set(asistencias.values_list('fecha__date', flat=True))
            semana_con_asistencias = asistencias.exists()  # Verificar si hay asistencias en la semana seleccionada

            # Determinar si la semana seleccionada es anterior a la semana actual
            semana_actual_inicio = timezone.localtime(timezone.now()).date() - timedelta(days=timezone.localtime(timezone.now()).date().weekday())
            semana_es_pasada = fin_semana < semana_actual_inicio

        # Verificar si hay asistencia registrada hoy
        fecha_hoy = timezone.localtime(timezone.now()).date()
        asistencia_hoy = Asistencia.objects.filter(asignatura=asignatura_seleccionada, fecha__date=fecha_hoy).exists()
        asistencias_hoy = Asistencia.objects.filter(asignatura=asignatura_seleccionada, fecha__date=fecha_hoy)

    context = {
        'cursos_con_asignaturas': cursos_con_asignaturas,
        'asignatura_seleccionada': asignatura_seleccionada,
        'semanas': semanas,
        'semana_seleccionada': semana_seleccionada if asignatura_seleccionada else None,
        'fechas_con_asistencias': sorted(fechas_con_asistencias),
        'asistencia_hoy': asistencia_hoy,
        'asistencias_hoy': asistencias_hoy,
        'semana_con_asistencias': semana_con_asistencias,
        'semana_es_pasada': semana_es_pasada,
    }
    return render(request, 'ver_asistencias_profesor.html', context)

@login_required
def agregar_asistencias_view(request, fecha):
    # Convertimos la fecha recibida a un formato adecuado
    if fecha == 'hoy':
        fecha = timezone.localtime(timezone.now()).date()
    else:
        fecha = datetime.strptime(fecha, '%Y-%m-%d').date()

    # Obtener la asignatura seleccionada del request
    asignatura_id = request.GET.get('curso')  # Aquí 'curso' se refiere al ID de la asignatura.
    if not asignatura_id:
        return HttpResponseBadRequest("No se ha especificado una asignatura para la asistencia.")

    # Obtener la asignatura y curso asociados
    asignatura = get_object_or_404(Asignatura, id=asignatura_id)
    curso = asignatura.curso
    alumnos = Alumno.objects.filter(curso=curso)

    # Recuperamos asistencias ya registradas para la fecha si existen
    asistencias_registradas = Asistencia.objects.filter(
        asignatura=asignatura, fecha__date=fecha
    )

    # Convertimos las asistencias registradas a un diccionario para acceder rápidamente
    asistencias_dict = {
        asistencia.alumno.id: asistencia
        for asistencia in asistencias_registradas
    }

    if request.method == 'POST':
        for alumno in alumnos:
            presente = request.POST.get(f'presente_{alumno.id}', 'false') == 'true'
            semestre = asignatura.semestre

            asistencia = asistencias_dict.get(alumno.id)

            if asistencia:
                asistencia.presente = presente
                asistencia.semestre = semestre
                asistencia.save()
            else:
                Asistencia.objects.create(
                    alumno=alumno,
                    asignatura=asignatura,
                    fecha=make_aware(datetime.combine(fecha, datetime.min.time())),
                    presente=presente,
                    semestre=semestre
                )

        messages.success(request, "La asistencia ha sido actualizada exitosamente.")
        return redirect(f'{reverse("ver_asistencias_profesor")}?curso={asignatura_id}')

    context = {
        'fecha': fecha,
        'alumnos': alumnos,
        'curso': curso,
        'alumnos_presentes': [a.alumno for a in asistencias_registradas if a.presente]
    }
    return render(request, 'agregar_asistencias.html', context)

@login_required
def ver_anotaciones_profesores_view(request):
    # Obtenemos las asignaturas que imparte el profesor
    asignaturas = Asignatura.objects.filter(profesor__usuario=request.user)
    
    # Crear una lista de asignaturas con sus cursos para el combo box
    cursos_con_asignaturas = [
        {
            'id': asignatura.id,
            'nombre': f"{asignatura.nombre} - {asignatura.curso.nombre}"
        }
        for asignatura in asignaturas
    ]

    # Obtener la asignatura seleccionada del request
    asignatura_id = request.GET.get('curso')
    asignatura_seleccionada = get_object_or_404(asignaturas, id=asignatura_id) if asignatura_id else None

    # Filtrar las anotaciones según la asignatura seleccionada
    if asignatura_seleccionada:
        alumnos = Alumno.objects.filter(curso=asignatura_seleccionada.curso)
        anotaciones = Anotacion.objects.filter(alumno__in=alumnos, asignatura=asignatura_seleccionada).order_by('-fecha')
    else:
        alumnos = []
        anotaciones = []

    context = {
        'cursos_con_asignaturas': cursos_con_asignaturas,
        'asignatura_seleccionada': asignatura_seleccionada,
        'alumnos': alumnos,
        'anotaciones': anotaciones,
    }
    return render(request, 'ver_anotaciones_profesores.html', context)

@login_required
def agregar_anotaciones_view(request, anotacion_id=None):
    # Usar la fecha de hoy según la zona horaria local
    fecha = timezone.localtime(timezone.now()).date()

    # Obtener la asignatura seleccionada del request
    asignatura_id = request.GET.get('curso')
    if not asignatura_id:
        return HttpResponseBadRequest("No se ha especificado una asignatura para la anotación.")

    asignatura = get_object_or_404(Asignatura, id=asignatura_id)
    curso = asignatura.curso
    alumnos = Alumno.objects.filter(curso=curso)

    # Si se proporciona un anotacion_id, obtener la anotación específica
    anotacion = None
    if anotacion_id:
        anotacion = get_object_or_404(Anotacion, id=anotacion_id, alumno__curso=curso)

    if request.method == 'POST':
        # Si hay una anotación existente, actualizamos la información
        if anotacion:
            descripcion = request.POST.get('descripcion', '').strip()
            tipo = request.POST.get('tipo', 'negativa')

            if descripcion:
                anotacion.descripcion = descripcion
                anotacion.tipo = tipo
                anotacion.save()
                messages.success(request, "La anotación ha sido actualizada exitosamente.")
            else:
                messages.error(request, "La descripción no puede estar vacía.")

        # Si no hay una anotación específica, permitir agregar una nueva
        else:
            for alumno in alumnos:
                descripcion = request.POST.get(f'descripcion_{alumno.id}', '').strip()
                tipo = request.POST.get(f'tipo_{alumno.id}', 'negativa')

                if descripcion:
                    Anotacion.objects.create(
                        alumno=alumno,
                        asignatura=asignatura,
                        fecha=make_aware(datetime.combine(fecha, datetime.min.time())),
                        descripcion=descripcion,
                        tipo=tipo
                    )

            messages.success(request, "Las anotaciones han sido registradas exitosamente.")

        return redirect(f'{reverse("ver_anotaciones_profesores")}?curso={asignatura_id}')

    # Preparar el contexto para la plantilla
    context = {
        'fecha': fecha,
        'alumnos': alumnos,
        'curso': curso,
        'asignatura': asignatura,
        'anotacion': anotacion,  # Pasar la anotación si se está editando
    }
    return render(request, 'agregar_anotaciones.html', context)

@login_required
def agregar_notas_view(request):
    # Obtener las asignaturas que el profesor puede seleccionar
    asignaturas = Asignatura.objects.filter(profesor__usuario=request.user)
    cursos_con_asignaturas = [
        {
            'id': asignatura.id,
            'nombre': f"{asignatura.nombre} - {asignatura.curso.nombre}"
        }
        for asignatura in asignaturas
    ]

    # Obtener la asignatura seleccionada del request
    asignatura_id = request.GET.get('curso')
    asignatura_seleccionada = get_object_or_404(asignaturas, id=asignatura_id) if asignatura_id else None
    curso_seleccionado = asignatura_seleccionada.curso if asignatura_seleccionada else None

    # Filtrar los alumnos del curso seleccionado
    alumnos = Alumno.objects.filter(curso=curso_seleccionado) if curso_seleccionado else []

    if request.method == 'POST':
        for alumno in alumnos:
            valor_nota = request.POST.get(f'nota_{alumno.id}', '').strip()

            # Determinar la próxima evaluación para este alumno individualmente
            max_evaluacion = Nota.objects.filter(
                alumno=alumno,
                asignatura=asignatura_seleccionada
            ).aggregate(Max('evaluacion'))['evaluacion__max'] or 0
            siguiente_evaluacion = max_evaluacion + 1

            # Validar que la nota esté en el rango correcto
            try:
                if valor_nota:
                    # Reemplazar coma por punto para convertir a flotante
                    valor_nota_float = float(valor_nota.replace(',', '.'))
                    if 1.0 <= valor_nota_float <= 7.0:
                        valor_nota = str(valor_nota_float)
                    else:
                        messages.error(
                            request, 
                            f'La nota debe estar entre 1,0 y 7,0 para {alumno.primer_nombre} {alumno.appaterno}.'
                        )
                        continue
                else:
                    valor_nota = "-"  # Valor predeterminado para notas vacías

                # Crear la nueva nota con la siguiente evaluación disponible
                Nota.objects.create(
                    alumno=alumno,
                    asignatura=asignatura_seleccionada,
                    evaluacion=siguiente_evaluacion,
                    nota=valor_nota,
                    semestre=curso_seleccionado.semestre
                )
            except ValueError:
                messages.error(
                    request, 
                    f'Valor de nota no válido para {alumno.primer_nombre} {alumno.appaterno}.'
                )

        messages.success(request, "Las notas han sido agregadas exitosamente.")
        return redirect(f'{reverse("ver_notas_profesor")}?curso={asignatura_id}')

    context = {
        'cursos_con_asignaturas': cursos_con_asignaturas,
        'asignatura_seleccionada': asignatura_seleccionada,
        'curso_seleccionado': curso_seleccionado,
        'alumnos': alumnos,
    }
    return render(request, 'agregar_notas.html', context)

@login_required
def ver_notas_profesor_view(request):
    # Obtener las asignaturas que imparte el profesor
    asignaturas = Asignatura.objects.filter(profesor__usuario=request.user)
    cursos_con_asignaturas = [
        {
            'id': asignatura.id,
            'nombre': f"{asignatura.nombre} - {asignatura.curso.nombre}"
        }
        for asignatura in asignaturas
    ]

    # Obtener la asignatura seleccionada desde el request
    asignatura_id = request.GET.get('curso')
    asignatura_seleccionada = get_object_or_404(asignaturas, id=asignatura_id) if asignatura_id else None
    curso_seleccionado = asignatura_seleccionada.curso if asignatura_seleccionada else None

    # Filtrar alumnos del curso seleccionado
    alumnos = Alumno.objects.filter(curso=curso_seleccionado) if curso_seleccionado else []

    # Recuperar todas las notas existentes y organizarlas por alumno y evaluación
    notas_dict = {}
    max_evaluacion = 0
    if curso_seleccionado:
        notas = Nota.objects.filter(alumno__in=alumnos, asignatura=asignatura_seleccionada).order_by('evaluacion')
        for nota in notas:
            notas_dict.setdefault(nota.alumno.id, {})[nota.evaluacion] = nota.nota

        # Determinar el número máximo de evaluaciones realizadas
        max_evaluacion = notas.aggregate(Max('evaluacion'))['evaluacion__max'] or 0
    
    # Crear una lista de evaluaciones para cada alumno, con guiones si no hay nota, y calcular el promedio
    notas_alumnos = []
    for alumno in alumnos:
        notas_alumno = {
            'alumno': alumno,
            'notas': [notas_dict.get(alumno.id, {}).get(i, '-') for i in range(1, max_evaluacion + 1)]
        }
        # Cálculo del promedio solo con las notas válidas
        notas_validas = [float(nota) for nota in notas_alumno['notas'] if nota != '-']
        notas_alumno['promedio'] = round(sum(notas_validas) / len(notas_validas), 1) if notas_validas else "-"
        notas_alumnos.append(notas_alumno)

    context = {
        'cursos_con_asignaturas': cursos_con_asignaturas,
        'asignatura_seleccionada': asignatura_seleccionada,
        'curso_seleccionado': curso_seleccionado,
        'notas_alumnos': notas_alumnos,
        'rango_evaluaciones': range(1, max_evaluacion + 1),
    }
    return render(request, 'ver_notas_profesor.html', context)

@login_required
def modificar_notas_view(request, alumno_id, asignatura_id):
    alumno = get_object_or_404(Alumno, id=alumno_id)
    asignatura = get_object_or_404(Asignatura, id=asignatura_id)
    notas = Nota.objects.filter(alumno=alumno, asignatura=asignatura).order_by('evaluacion')

    # Convertir las notas al formato decimal con coma para visualización
    for nota in notas:
        if nota.nota and nota.nota != "-":
            # Asegurarse de que el formato sea decimal con coma
            nota.nota_int = str(float(nota.nota)).replace('.', ',')
        else:
            nota.nota_int = ""

    if request.method == 'POST':
        for nota in notas:
            nueva_nota = request.POST.get(f'nota_{nota.evaluacion}')
            if nueva_nota:
                try:
                    # Convertir el valor ingresado en el formato correcto
                    nueva_nota_decimal = float(nueva_nota.replace(',', '.'))
                    if 1.0 <= nueva_nota_decimal <= 7.0:
                        nota.nota = str(nueva_nota_decimal)  # Guardar en formato decimal
                        nota.save()
                    else:
                        messages.error(request, f'La nota debe estar entre 1,0 y 7,0 para la evaluación {nota.evaluacion}.')
                except ValueError:
                    messages.error(request, f'Valor de nota no válido para la evaluación {nota.evaluacion}.')

        messages.success(request, "Las notas han sido actualizadas exitosamente.")
        return redirect(f'{reverse("ver_notas_profesor")}?curso={asignatura_id}')

    context = {
        'alumno': alumno,
        'asignatura': asignatura,
        'notas': notas,
    }
    return render(request, 'modificar_notas.html', context)

@login_required
@user_passes_test(lambda u: Profesor.objects.filter(usuario=u, es_jefe=True).exists(), login_url='login')
def registro_profesor_jefe_view(request):
    return render(request, 'registro_profesor_jefe.html')

@login_required
@user_passes_test(lambda u: Profesor.objects.filter(usuario=u, es_jefe=True))
def registro_curso_jefe_view(request):
    return render(request, 'registro_curso_jefe.html')

@login_required
@user_passes_test(lambda u: Profesor.objects.filter(usuario=u, es_jefe=True).exists())
def ver_notas_jefe_view(request):
    profesor_jefe = get_object_or_404(Profesor, usuario=request.user, es_jefe=True)
    curso = profesor_jefe.curso

    alumnos = Alumno.objects.filter(curso=curso)

    alumno_id = request.GET.get('alumno')
    alumno_seleccionado = None
    notas_dict = {}
    max_evaluacion = 0
    
    if alumno_id:
        alumno_seleccionado = get_object_or_404(alumnos, id=alumno_id)
        notas = Nota.objects.filter(alumno=alumno_seleccionado).order_by('evaluacion')
        for nota in notas:
            notas_dict.setdefault(nota.asignatura.nombre, {})[nota.evaluacion] = nota.nota
        max_evaluacion = notas.aggregate(Max('evaluacion'))['evaluacion__max'] or 0

    notas_asignaturas = []
    if alumno_seleccionado:
        asignaturas = Asignatura.objects.all()
        for asignatura in asignaturas:
            notas_asignatura = {
                'asignatura': asignatura.nombre,
                'notas': [notas_dict.get(asignatura.nombre, {}).get(i, '-') for i in range(1, max_evaluacion + 1)]
            }
            notas_validas = [float(nota) for nota in notas_asignatura['notas'] if nota != '-']
            notas_asignatura['promedio'] = round(sum(notas_validas) / len(notas_validas), 1) if notas_validas else "-"
            notas_asignaturas.append(notas_asignatura)

    context = {
        'alumnos': alumnos,
        'alumno_seleccionado': alumno_seleccionado,
        'notas_asignaturas': notas_asignaturas,
        'rango_evaluaciones': range(1, max_evaluacion + 1),
    }
    return render(request, 'ver_notas_jefe.html', context)

@login_required
@user_passes_test(lambda u: Profesor.objects.filter(usuario=u, es_jefe=True).exists())
def ver_anotaciones_jefe_view(request):
    # Obtener el profesor jefe actual
    profesor_jefe = get_object_or_404(Profesor, usuario=request.user, es_jefe=True)
    curso = profesor_jefe.curso

    # Obtener los alumnos del curso del profesor jefe
    alumnos = Alumno.objects.filter(curso=curso)

    # Obtener el alumno seleccionado desde el request
    alumno_id = request.GET.get('alumno')
    alumno_seleccionado = None
    anotaciones = None

    if alumno_id:
        alumno_seleccionado = get_object_or_404(alumnos, id=alumno_id)
        # Obtener las anotaciones del alumno seleccionado
        anotaciones = Anotacion.objects.filter(alumno=alumno_seleccionado).order_by('-fecha')

    return render(request, 'ver_anotaciones_jefe.html', {
        'alumnos': alumnos,
        'alumno_seleccionado': alumno_seleccionado,
        'anotaciones': anotaciones,
    })

@login_required
@user_passes_test(lambda u: Profesor.objects.filter(usuario=u, es_jefe=True).exists())
def ver_asistencias_jefe_view(request):
    # Obtener el profesor jefe actual
    profesor_jefe = get_object_or_404(Profesor, usuario=request.user, es_jefe=True)
    curso = profesor_jefe.curso

    # Obtener los alumnos del curso del profesor jefe
    alumnos = Alumno.objects.filter(curso=curso)

    # Obtener el alumno seleccionado desde el request
    alumno_id = request.GET.get('alumno')
    alumno_seleccionado = None
    asistencias = None
    semanas = []
    semana_seleccionada = None

    if alumno_id:
        alumno_seleccionado = get_object_or_404(alumnos, id=alumno_id)
        # Busca todas las asistencias del alumno seleccionado
        asistencias = Asistencia.objects.filter(alumno=alumno_seleccionado).order_by('-fecha')

        # Calcular las semanas disponibles a partir de las fechas de asistencia
        fechas = asistencias.values_list('fecha__date', flat=True).distinct()
        for fecha in sorted(fechas):
            inicio_semana = fecha - timedelta(days=fecha.weekday())  # Lunes de esa semana
            fin_semana = inicio_semana + timedelta(days=6)  # Domingo de esa semana
            semanas.append((inicio_semana, fin_semana))
        semanas = list(set(semanas))
        semanas.sort()

        # Filtrar asistencias por la semana seleccionada
        semana_seleccionada = request.GET.get('semana')
        if semana_seleccionada:
            inicio_semana_str, fin_semana_str = semana_seleccionada.split('_')
            inicio_semana = datetime.strptime(inicio_semana_str, '%Y-%m-%d').date()
            fin_semana = datetime.strptime(fin_semana_str, '%Y-%m-%d').date()
            asistencias = asistencias.filter(fecha__date__range=(inicio_semana, fin_semana))

    return render(request, 'ver_asistencias_jefe.html', {
        'alumnos': alumnos,
        'alumno_seleccionado': alumno_seleccionado,
        'asistencias': asistencias,
        'semanas': semanas,
        'semana_seleccionada': semana_seleccionada if alumno_seleccionado else None,
    })

@login_required
def ver_notas_apoderado_view(request):
    # Obtener los alumnos asignados al apoderado actual
    alumnos = Alumno.objects.filter(apoderado=request.user)
    alumnos_data = [{'id': alumno.id, 'nombre': f"{alumno.primer_nombre} {alumno.appaterno}"} for alumno in alumnos]

    # Obtener el alumno y asignatura seleccionados
    alumno_id = request.GET.get('alumno')
    asignatura_id = request.GET.get('asignatura')
    alumno_seleccionado = get_object_or_404(alumnos, id=alumno_id) if alumno_id else None
    asignatura_seleccionada = Asignatura.objects.filter(id=asignatura_id).first() if asignatura_id else None

    # Datos de la tabla de notas por asignatura
    notas_dict = {}
    max_evaluacion = 0
    if alumno_seleccionado:
        notas = Nota.objects.filter(alumno=alumno_seleccionado).order_by('evaluacion')
        for nota in notas:
            notas_dict.setdefault(nota.asignatura.nombre, {})[nota.evaluacion] = nota.nota
        max_evaluacion = notas.aggregate(Max('evaluacion'))['evaluacion__max'] or 0

    notas_asignaturas = []
    if alumno_seleccionado:
        asignaturas = Asignatura.objects.all()
        for asignatura in asignaturas:
            notas_asignatura = {
                'asignatura': asignatura.nombre,
                'notas': [notas_dict.get(asignatura.nombre, {}).get(i, '-') for i in range(1, max_evaluacion + 1)]
            }
            notas_validas = [float(nota) for nota in notas_asignatura['notas'] if nota != '-']
            notas_asignatura['promedio'] = round(sum(notas_validas) / len(notas_validas), 1) if notas_validas else "-"
            notas_asignaturas.append(notas_asignatura)

    # Datos del gráfico de la asignatura seleccionada
    evaluaciones = []
    notas_alumno = []
    notas_curso = []
    if alumno_seleccionado and asignatura_seleccionada:
        notas_asignatura = Nota.objects.filter(alumno=alumno_seleccionado, asignatura=asignatura_seleccionada).order_by('evaluacion')
        evaluaciones = [nota.evaluacion for nota in notas_asignatura]
        notas_alumno = [nota.nota for nota in notas_asignatura]

        curso = alumno_seleccionado.curso
        notas_curso = [
            Nota.objects.filter(asignatura=asignatura_seleccionada, alumno__curso=curso, evaluacion=evaluacion)
            .exclude(alumno=alumno_seleccionado)
            .aggregate(promedio=Avg('nota'))['promedio'] or 0
            for evaluacion in evaluaciones
        ]

    context = {
        'alumnos_data': alumnos_data,
        'alumno_seleccionado': alumno_seleccionado,
        'asignaturas': Asignatura.objects.all(),
        'asignatura_seleccionada': asignatura_seleccionada,
        'notas_asignaturas': notas_asignaturas,
        'rango_evaluaciones': range(1, max_evaluacion + 1),
        'evaluaciones': evaluaciones,
        'notas_alumno': notas_alumno,
        'notas_curso': notas_curso,
    }
    return render(request, 'ver_notas_apoderado.html', context)

def render_to_pdf(template_src, context_dict={}):
    template = get_template(template_src)
    html = template.render(context_dict)
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="notas_alumno.pdf"'
    pisa_status = pisa.CreatePDF(html, dest=response)
    if pisa_status.err:
        return HttpResponse('Error al generar el PDF', status=500)
    return response

def pdf_notas_view(request):
    alumno_id = request.GET.get('alumno')
    alumno = get_object_or_404(Alumno, id=alumno_id)
    notas = Nota.objects.filter(alumno=alumno).order_by('asignatura', 'evaluacion')
    
    asignaturas = Asignatura.objects.all()
    notas_asignaturas = []
    max_evaluacion = notas.aggregate(Max('evaluacion'))['evaluacion__max'] or 0
    suma_promedios = 0
    asignaturas_con_promedio = 0

    for asignatura in asignaturas:
        notas_asignatura = {
            'asignatura': asignatura.nombre,
            'notas': [notas.filter(asignatura=asignatura, evaluacion=i).first().nota if notas.filter(asignatura=asignatura, evaluacion=i).exists() else '-' for i in range(1, max_evaluacion + 1)]
        }
        notas_validas = [float(nota) for nota in notas_asignatura['notas'] if nota != '-']
        if notas_validas:
            promedio = round(sum(notas_validas) / len(notas_validas), 1)
            notas_asignatura['promedio'] = promedio
            suma_promedios += promedio
            asignaturas_con_promedio += 1
        else:
            notas_asignatura['promedio'] = "-"
        notas_asignaturas.append(notas_asignatura)

    # Calcular el promedio final
    promedio_final = round(suma_promedios / asignaturas_con_promedio, 1) if asignaturas_con_promedio > 0 else "-"

    # Agregar el número de columnas en la tabla al contexto
    num_columnas = max_evaluacion + 2  # +1 para la columna de "Asignatura" y +1 para "Promedio"

    context = {
        'alumno': alumno,
        'notas_asignaturas': notas_asignaturas,
        'rango_evaluaciones': range(1, max_evaluacion + 1),
        'promedio_final': promedio_final,
        'num_columnas': num_columnas
    }
    return render_to_pdf('plantilla_pdf.html', context)

def eliminar_anotacion(request, anotacion_id):
    anotacion = get_object_or_404(Anotacion, id=anotacion_id)
    if request.method == "POST":
        anotacion.delete()
        # Redirige a la página anterior
        return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))