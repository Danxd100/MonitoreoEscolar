from django import forms
from django.forms import DateInput

from .models import Curso, AnoEscolar, Semestre, Asignatura, Alumno, Usuario

#from .models import Asignatura

class AnoForm(forms.ModelForm):
    class Meta:
        model = AnoEscolar
        fields = ['nombre']

class SemestreForm(forms.ModelForm):
    class Meta:
        model = Semestre
        fields = ['nombre','inicio','fin','ano_escolar']
        widgets = {
            'inicio': DateInput(attrs={'type': 'date'}),
            'fin': DateInput(attrs={'type': 'date'}),
        }

class CursoForm(forms.ModelForm):
    class Meta:
        model = Curso
        fields = ['nombre','semestre']

class AsignaturaForm(forms.ModelForm):
    class Meta:
        model = Asignatura
        fields = ['nombre', 'curso', 'semestre']

class AlumnoForm(forms.ModelForm):
    class Meta:
        model = Alumno
        fields = ['rut', 'primer_nombre', 'segundo_nombre', 'appaterno', 'apmaterno', 'curso', 'apoderado']

class ProfesorForm(forms.ModelForm):
    class Meta:
        model = Usuario
        fields = ['rut', 'primer_nombre', 'segundo_nombre', 'appaterno', 'apmaterno']
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Fija el campo 'tipo' como 'profesor'
        self.instance.tipo = 'profesor'

class ApoderadoForm(forms.ModelForm):
    class Meta:
        model = Usuario
        fields = ['rut', 'primer_nombre', 'segundo_nombre', 'appaterno', 'apmaterno']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Fija el campo 'tipo' como 'apoderado'
        self.instance.tipo = 'apoderado'


